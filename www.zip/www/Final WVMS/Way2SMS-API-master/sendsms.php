<?php 
    include('way2sms-api.php');
    $client = new WAY2SMSClient();
    $client->login('9611014654', 'akashanitha');
    $client->send('8867724616', 'Hello From AJay');
    //Add sleep between requests to make this requests more human like! 
    //A blast of request's may mark the ip as spammer and blocking further requests.
    sleep(1);
   // $client->send('987654321,9876501234', 'msg2');
   // sleep(1);
    $client->logout();
?>