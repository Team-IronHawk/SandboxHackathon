<?php include('header1.php');


?>

<form id="form2" name="form2" method="post" action="saveengagement.php">

<table  width="417" border="1" >
  <tr>
    <td width="107">Topic</td>
    <td  width="294">
      <label></label>
      <select name="topic" size="1" id="topic">
        <option>1 Registration with Anganwadi and Asha</option>
        <option>2 Importance of 3 ANC Checkups</option>
        <option>3 TT Injection</option>
        <option>4 Iron Tablets</option>
        <option>5 Nutritious Food</option>
        <option>6 Do's and Don&rsquo;ts</option>
        <option>7 High Risk Pregnancy</option>
        <option>8 Preparation for Delivery</option>
        <option>9 Institutional Delivery</option>
        <option>10 Signs of Danger Post Delivery</option>
        <option>11 New Born Care</option>
        </select>
      </td>
  </tr>
  <tr>
    <td>High risk </td>
    <td>
      <p>
        <label>
        <select name="risk" id="risk">
        <option>Yes</option>
		<option>No</option>
		</select>
        </label>
      </p>
    </td>
  </tr>
  <tr>
    <td>Criteria</td>
    <td>
      <label>
      <select name="criteria" id="criteria">
        <option>1Below 40KG (Weight)</option>
        <option>2BP Below 100/60</option>
        <option>3BP Above 140/100</option>
        <option>4HB Below 8</option>
        </select>
        </label>
     </td>
  </tr>
  <tr>
    <td>Date And Time of Visit</td>
    <td><label>
      <input name="date" type="text" id="date" />
    </label></td>
  </tr>
  <tr>
    <td height="26">&nbsp;</td>
    <td><input type="submit" name="Submit" value="Submit" />
    <input type="reset" name="Submit2" value="Reset" /></td>
  </tr>
</table>
<?php include('footer.php')?>
