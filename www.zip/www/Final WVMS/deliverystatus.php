<?php include('header1.php'); ?>
<form id="form1" name="form1" method="post" action="savedelivery.php">
<table width="180" border="1" align="left">
  <tr>
    <td width="81">Gravida</td>
    <td width="83" nowrap="nowrap"><select name="gravida" size="1" id="gravida">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
        </select></td>
  </tr>
  <tr>
    <td>POD</td>
    <td><select name="pod" size="1" id="pod">
      <option>Home</option>
      <option>Hospital</option>
        </select></td>
  </tr>
  
  <tr>
    <td>Baby weight </td>
    <td><label>
      <input name="weight" type="text" id="weight">
    </label></td>
  </tr>
  <tr>
    <td>Mortality</td>
    <td><select name="morality" size="1" id="morality">
      <option>None</option>
      <option>Mother</option>
      <option>Child</option>
        </select></td>
  </tr>
  <tr>
    <td>did</td>
    <td><label>
      <input name="did" type="text" id="did">
    </label></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><label>
      <input type="submit" name="Submit" value="Submit" />
      <input name="Reset" type="reset" id="Reset" value="Reset" />
    </label></td>
  </tr>
  
</table>
</form>
<?php include('footer.php'); ?>


