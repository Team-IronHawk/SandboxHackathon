
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>WVMS</title>
<link rel="stylesheet" href="../Final AD/styles.css" type="text/css" />
<link rel="stylesheet" href="../Final AD/styles.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="../Final AD/CalendarControl.css" />
<script language="JavaScript" src="../Final AD/CalendarControl.js" type="text/javascript"></script>

<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--
educate, a free CSS web template by ZyPOP (zypopwebtemplates.com/)

Download: http://zypopwebtemplates.com/

License: Creative Commons Attribution
//-->

<script type="text/javascript" src="../Final AD/js/jquery.js"></script>
<script type="text/javascript" src="../Final AD/js/slider.js"></script>
<script type="text/javascript" src="../Final AD/js/superfish.js"></script>

<script type="text/javascript" src="../Final AD/js/custom.js"></script>

<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
</head>
<body bgcolor="PINK">
<br><br>
<div id="container">

    <header id="header" class="hoc clear"> 
      <!-- ################################################################################################ -->
      <div id="logo" class="fl_left">
        <a href=index.html"><h1>COLLECTION OF HEALTH OF PREGNANT WOMEN AND CHECKUP</h1></a>
      </div><br><br>
	  
      <nav id="mainav" class="fl_right">
        <ul class="clear">
         <h3> <a href="home.php">Home</a></h3>
                        <h3><a href="patient.php">PATIENT</a></h3>
              <h3><a href="delivery.php">DELIVERY</a></h3>
              <h3><a href="engagement.php">ENGAGEMENT</a></h3>
              <h3><a href="feedback.php">FEEDBACK</a></h3>
             
          
               <h3><a href="viewpatient.php">PATIENT DETAILS</a></h3>
              
           
          
        </ul>
      </nav>
      <!-- ################################################################################################ -->
    </header>
	<br><br><br><br><br><br>



    <div id="body" class="width" align="center">
    </div>
	
		<div class="clear"></div>
	
    </nav>


	 <div id="slides-container" class="slides-container width">
        <div id="slides">
          <div>
                
		   <img src="images1.jpg" alt="Placeholder image" width="1069" />
		            
          </div> 
		<div>
                
		   <img src="image2.jpg" alt="Placeholder image" width="1069" />
		            
          </div> 
          <div>
                
		   <img src="image3.jpg" alt="Placeholder image" width="1069" />
		            
          </div> 
		      
		</div>
        <div class="controls"><span class="jFlowNext"><span>Next</span></span><span class="jFlowPrev"><span>Prev</span></span></div>        
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <div id="myController" class="hidden">
		<!-- COPY AND PASTE SLIDE CONTROL FOR EACH NEW SLIDE -->
		<span class="jFlowControl">Slide 1</span>
		<span class="jFlowControl">Slide 2</span>
		<span class="jFlowControl">Slide 3</span>
		<span class="jFlowControl">Slide 4</span>
	</div>
    </div>

    

    </header>




   <?php include('footer.php'); ?>