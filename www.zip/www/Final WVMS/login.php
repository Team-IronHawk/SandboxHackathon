
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>WVMS</title>
<link rel="stylesheet" href="../Final AD/styles.css" type="text/css" />
<link rel="stylesheet" href="../Final AD/styles.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="../Final AD/CalendarControl.css" />
<script language="JavaScript" src="../Final AD/CalendarControl.js" type="text/javascript"></script>

<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--
educate, a free CSS web template by ZyPOP (zypopwebtemplates.com/)

Download: http://zypopwebtemplates.com/

License: Creative Commons Attribution
//-->

<script type="text/javascript" src="../Final AD/js/jquery.js"></script>
<script type="text/javascript" src="../Final AD/js/slider.js"></script>
<script type="text/javascript" src="../Final AD/js/superfish.js"></script>

<script type="text/javascript" src="../Final AD/js/custom.js"></script>

<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
</head>
<body bgcolor="PINK">
<br><br>
<div id="container">

    <header id="header" class="hoc clear"> 
      <!-- ################################################################################################ -->
      <div id="logo" class="fl_left">
        <h2><a href=index.html">COLLECTION OF HEALTH OF PREGNANT WOMEN AND CHECKUP</a></h2>
      </div><br><br>
	  
      <nav id="mainav" class="fl_right">
        <ul class="clear">
         <h3> <a href="index.php">Home</a>
           </h3>            
              
           
          
        </ul>
      </nav>
      <!-- ################################################################################################ -->
    </header>
	<br><br><br><br><br><br>
<div id="body" class="width" align="center">
	  <form id="form1" name="form1" method="post" action="chklogin.php">
	    <table width="200" border="1">
          <tr>
            <td  class="lhead">USERNAME</td>
            <td  class="ldata"><label>
              <input name="uname" type="text" id="uname" />
            </label></td>
          </tr>
          <tr>
            <td  class="lhead">PASSWORD</td>
            <td  class="ldata"><label>
              <input name="pwd" type="password" id="pwd" />
            </label></td>
          </tr>
        </table>
        <p>
          <label>
         <input type="submit" name="Submit" value="Login" />
          </label>
        </p>
	  </form>
</div>
<br><br><br><br><br><br><br><br><br>
