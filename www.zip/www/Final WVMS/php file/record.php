<?php include('header1.php'); ?>
<p>Medical Record : </p>
<table width="324" border="1">
  <tr>
    <td width="120">HB</td>
    <td width="188"><form id="" name="" method="post" action="">
      <label>
        <input name="hb" type="text" id="hb" />
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td>BP</td>
    <td><form id="form3" name="form3" method="post" action="">
      <label>
        <input name="bp" type="text" id="bp" />
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td>Weight(In KG)</td>
    <td><form id="form4" name="form4" method="post" action="">
      <label>
      <input name="weight" type="text" id="weight" />
      </label>
        </form>    </td>
  </tr>
  <tr>
    <td>Urine Test </td>
    <td><form id="form1" name="form1" method="post" action="">
      <p>
        <label>
        <input type="radio" name="RadioGroup1" value="radio" />
Yes</label>
        <br />
        <label>
        <input type="radio" name="RadioGroup1" value="radio" />
No</label>
        <br />
      </p>
    </form>    </td>
  </tr>
  <tr>
    <td>Scanning 1st Date </td>
    <td><form id="form5" name="form5" method="post" action="">
      <label>
        <input name="scan1" type="text" id="scan1" />
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td height="45">Scanning 2nd Date </td>
    <td><form id="form6" name="form6" method="post" action="">
      <label>
        <input name="scan2" type="text" id="scan2" />
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td height="66">&nbsp;</td>
    <td><input type="submit" name="Submit" value="Submit" />
    <input type="reset" name="Submit2" value="Reset" /></td>
  </tr>
</table>
<form id="form2" name="form2" method="post" action="">
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h1>&nbsp;</h1>
<?php include('footer.php'); ?>
