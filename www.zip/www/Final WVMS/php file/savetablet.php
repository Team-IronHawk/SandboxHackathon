<?php include('header1.php');?>
<table width="200" border="1">
  <tr>
    <td width="93">3rd month </td>
    <td width="91"><form id="form3" name="form3" method="post" action="">
      <label>
        <input name="month3" type="text" id="month3" />
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td>4th month </td>
    <td><form id="form4" name="form4" method="post" action="">
      <label>
        <input name="month4" type="text" id="month4" />
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td>5th month </td>
    <td><form id="form5" name="form5" method="post" action="">
      <label>
        <input name="month5" type="text" id="month5" />
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td>Injection taken </td>
    <td><form id="form1" name="form1" method="post" action="">
      <table width="200">
        <tr>
          <td><label>
            <input type="radio" name="values" value="radio" />
            yes</label></td>
        </tr>
        <tr>
          <td><label>
            <input name="values" type="radio" value="radio" />
            no</label></td>
        </tr>
      </table>
    </form>    </td>
  </tr>
  <tr>
    <td>Injection 1st date </td>
    <td><form id="form6" name="form6" method="post" action="">
      <label>
        <input name="date1" type="text" id="date1" />
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td>Injection 2nd date </td>
    <td><form id="form7" name="form7" method="post" action="">
      <label>
        <input name="date2" type="text" id="date2" />
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td bordercolor="#FFFFFF" bgcolor="#FFFFFF">Booster dose </td>
    <td><form id="form2" name="form2" method="post" action="">
      <table width="200">
        <tr>
          <td><label>
            <input type="radio" name="values" value="radio" />
            yes</label></td>
        </tr>
        <tr>
          <td><label>
            <input type="radio" name="values" value="radio" />
            no</label></td>
        </tr>
      </table>
    </form>    </td>
  </tr>
  <tr>
    <td bordercolor="#FFFFFF" bgcolor="#FFFFFF">tid</td>
    <td><form id="form8" name="form8" method="post" action="">
      <label>
        <input name="tid" type="text" id="tid" />
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td bordercolor="#FFFFFF" bgcolor="#FFFFFF">&nbsp;</td>
    <td><input type="submit" name="Submit" value="Submit" />
    <input type="reset" name="Submit2" value="Reset" /></td>
  </tr>
</table>
<h3>&nbsp;</h3>
<?php include('footer.php');?>
