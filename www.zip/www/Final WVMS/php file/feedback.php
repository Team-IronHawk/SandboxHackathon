<?php include('header1.php'); ?>
<p>Pregnant Women Feedback</p>
<table width="290" border="1">
  <tr>
    <td width="110">Clarity Of Information </td>
    <td width="164"><form id="form1" name="form1" method="post" action="">
      <label>
      <select name="information" size="1" id="information">
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
            </select>
</label>
    </form>    </td>
  </tr>
  <tr>
    <td>Usefullness</td>
    <td><form id="form2" name="form2" method="post" action="">
      <label>
      <select name="useful" id="useful">
          <option>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
        </select>
      </label>
    </form>    </td>
  </tr>
  <tr>
    <td>Understanding</td>
    <td><form id="form3" name="form3" method="post" action="">
      <label>
      <select name="understand" id="understand">
          <option>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
        </select>
        </label>
      <label></label>
      <label></label>
    </form>    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Submit" />
      <input type="reset" name="Submit2" value="Reset" /></td>
  </tr>
</table>
<?php include('footer.php'); ?>
