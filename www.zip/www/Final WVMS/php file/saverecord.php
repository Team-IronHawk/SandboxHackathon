<?php include('dbconnect.php'); ?>
<?php
$hb=$_POST['hb'];
$bp=$_POST['bp'];
$weight=$_POST['weight'];
$scan1=$_POST['scan1'];
$scan2=$_POST['scan2'];

$sql="insert into medical values('$hb','$bp','$weight','$scan1','$scan2')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New attendence inserted successfully");
</script>