<?php include('dbconnect.php'); ?>
<?php
$information=$_POST['information'];
$useful=$_POST['useful'];
$understand=$_POST['understand'];


$sql="insert into medical values('$information','$useful','$understand')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New attendence inserted successfully");
</script>