
<?php include('dbconnect.php'); ?>
<?php
$month3=$_POST['month3'];
$month4=$_POST['month4'];
$month5=$_POST['month5'];
$date1=$_POST['date1'];
$date2=$_POST['date2'];
$tid=$_POST['tid'];
$sql="insert into tablet values('$month3','$month4','$month5','$date1','$date2','$tid')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New record added successfully");
</script>