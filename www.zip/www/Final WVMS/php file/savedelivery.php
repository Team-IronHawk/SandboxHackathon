<?php include('dbconnect.php'); ?>
<?php
$gravida=$_POST['gravida'];
$pod=$_POST['pod'];
$weight=$_POST['weight'];
$morality=$_POST['morality'];
$did=$_POST['did'];
$sql="insert into delivery values('$gravida','$pod','$weight','$morality','$did')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("delivery details inserted successfully");
</script>