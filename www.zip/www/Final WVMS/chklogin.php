<?php  session_start();
$aduname=$_POST['uname'];
$adpwd=$_POST['pwd'];
if($aduname=="admin" && $adpwd=="admin")
{
$_SESSION['aduname']=$aduname;
$_SESSION['adpwd']=$adpwd;

header("location:home.php");
}
else
{
?>
<script>
alert("Invalid Login Details...Try Again...");
document.location="login.php"
</script>
<?php

}?>