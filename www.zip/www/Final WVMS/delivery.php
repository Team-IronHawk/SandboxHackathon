<?php include('header1.php'); ?>
<table width="200" border="1">
<form id="form1" name="form1" method="post" action="savedelivery.php">
  <tr>
    <td width="68">Gravida</td>
    <td width="116">
	
	<select name="gravida" size="1" id="gravida">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select></td>
  </tr>
  <tr>
    <td>POD</td>
    <td><select name="pod" size="1" id="pod">
      <option>Home</option>
      <option>Hospital</option>
    </select></td>
  </tr>
  <tr>
    <td>Baby weight</td>
    <td><input name="weight" type="text" id="weight" /></td>
  </tr>
  <tr>
    <td>Mortality</td>
    <td><select name="morality" size="1" id="morality">
      <option>None</option>
      <option>Mother</option>
      <option>Child</option>
    </select></td>
  </tr>
  <tr>
    <td>did</td>
    <td><input name="did" type="text" id="did" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Submit" />
      <input name="Reset" type="reset" id="Reset" value="Reset" /></td>
  </tr>
  </form>
</table>
<?php include('footer.php'); ?>
