<?php include('header1.php'); ?>
<form id="form2" name="form2" method="post" action="savefeedback.php">
<table width="200" border="1">
  <tr>
    <td width="84">Information</td>
    <td width="100"><label>
    <select name="information" id="information">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select>
    </label></td>
  </tr>
  <tr>
    <td>Useful</td>
    <td><label>
      <select name="useful" id="useful">
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
      </select>
    </label></td>
  </tr>
  <tr>
    <td>Understand</td>
    <td><label>
      <select name="understand" id="understand">
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
      </select>
    </label></td>
  </tr>
  <tr>
    <td>FID</td>
    <td><label>
      <input name="fid" type="text" id="fid" />
    </label></td>
  </tr>
  <tr>
    <td><input type="submit" name="Submit" value="Submit" /></td>
    <td><label>
      <input name="Reset" type="reset" id="Reset" value="Reset" />
    </label></td>
  </tr>
</table>
</form>
<?php include('footer.php'); ?>

