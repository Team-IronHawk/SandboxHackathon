<?php include('header1.php'); ?>

<form action="savepatient.php" method="post" enctype="multipart/form-data"s>
<table  width="409" height="363" border="1" align="center">
  <tr>
    <td width="230">ID</td>
    <td width="163"><label>
      <input name="id" type="text" id="id">
    </label></td>
  </tr>
  <tr>
    <td height="33">FULL NAME </td>
    <td><input name="fname" type="text" id="fname" /></td>
  </tr>
  <tr>
    <td>HUSBAND NAME </td>
    <td><input name="hname" type="text" id="hname" /></td>
  </tr>
  <tr>
    <td>UID IMAGE</td>
    <td><input name="fileToUpload" type="file" ></td>
  </tr>
  <tr>
    <td height="42">EXPECTED DATE OF DELIVERY </td>
    <td><input name="dod" type="text" id="dod" /></td>
  </tr>
  <tr>
    <td>AGE </td>
    <td><input name="age" type="text" id="age" /></td>
  </tr>
  <tr>
    <td>MOBILE </td>
    <td><input name="mobile" type="text" id="mobile" /></td>
  </tr>
  <tr>
    <td>PHOTO</td>
    <td><input name="fileToUpload1" type="file" ></td>
	  </tr>
  <tr>
    <td>ADDRESS</td>
    <td><input name="address" type="text" id="address" /></td>
  </tr>
  <tr>
    <td height="54"><input type="submit" name="Submit3" value="Submit" /></td>
    <td><input type="reset" name="Submit4" value="Reset" /></td>
  </tr>
</table>
<?php include('footer.php'); ?>
