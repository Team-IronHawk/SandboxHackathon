<?php
$con=mysql_connect('localhost','root','');
mysql_select_db('women',$con);
?>
<?php
$id=$_POST['id'];
$fname=$_POST['fname'];
$hname=$_POST['hname'];
$dod=$_POST['dod'];
$age=$_POST['age'];
$mobile=$_POST['mobile'];
$image=$_POST['image'];
$address=$_POST['address'];
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$name=basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$uid = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 5000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($uid != "jpg" && $uid != "png" && $uid != "jpeg"
&& $uid != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
		echo "YOUR FILE HAS BEEN UPLOADED SUCCESSFULLY";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
$target_file1 = $target_dir . basename($_FILES["fileToUpload1"]["name"]);
$name=basename($_FILES["fileToUpload1"]["name"]);
$uploadOk = 1;
$image = pathinfo($target_file1,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload1"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file1)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload1"]["size"] > 5000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($image != "jpg" && $image != "png" && $image != "jpeg"
&& $image != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload1"]["tmp_name"], $target_file1)) {
		
		echo "YOUR FILE HAS BEEN UPLOADED SUCCESSFULLY";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}




$sql="insert into patient values('$id','$fname','$hname','$target_file','$dod','$age','$mobile','$target_file1','$address')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New data inserted successfully");
document.location="patient.php";
</script>
