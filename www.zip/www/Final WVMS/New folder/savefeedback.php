<?php
$con=mysql_connect('localhost','root','');
mysql_select_db('women',$con);
?>
<?php
$information=$_POST['information'];
$useful=$_POST['useful'];
$understand=$_POST['understand'];
$fid=$_POST['fid'];

$sql="insert into feedback values('$information','$useful','$understand','$fid')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New feedback inserted successfully");
document.location="feedback.php";
</script>