
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>WVMS</title>
<link rel="stylesheet" href="../Final AD/styles.css" type="text/css" />
<link rel="stylesheet" href="../Final AD/styles.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="../Final AD/CalendarControl.css" />
<script language="JavaScript" src="../Final AD/CalendarControl.js" type="text/javascript"></script>

<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--
educate, a free CSS web template by ZyPOP (zypopwebtemplates.com/)

Download: http://zypopwebtemplates.com/

License: Creative Commons Attribution
//-->

<script type="text/javascript" src="../Final AD/js/jquery.js"></script>
<script type="text/javascript" src="../Final AD/js/slider.js"></script>
<script type="text/javascript" src="../Final AD/js/superfish.js"></script>

<script type="text/javascript" src="../Final AD/js/custom.js"></script>

<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
</head>
<body bgcolor="PINK">
<br><br>
<div id="container">

    <header id="header" class="hoc clear"> 
      <!-- ################################################################################################ -->
      <div id="logo" class="fl_left">
        <h2><a href=index.html">COLLECTION OF HEALTH OF PREGNANT WOMEN AND CHECKUP</a></h2>
      </div><br><br>
	  
      <nav id="mainav" class="fl_right">
        <ul class="clear">
          <br><a href="home.php">Home</a></br>
                        <br><a href="patient.php">PATIENT</a></br>
              <br><a href="delivery.php">DELIVERY</a></br>
              <br><a href="engagement.php">ENGAGEMENT</a></br>
              <br><a href="feedback.php">FEEDBACK</a></br>
             
          
              
              
           
          
        </ul>
      </nav>
      <!-- ################################################################################################ -->
    </header>
	<br><br><br><br><br><br>



    
