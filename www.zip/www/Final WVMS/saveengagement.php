<?php
$con=mysql_connect('localhost','root','');
mysql_select_db('women',$con);
?>
<?php
$topic=$_POST['topic'];
$risk=$_POST['risk'];
$criteria=$_POST['criteria'];
$date=$_POST['date'];
$sql="insert into engage values('$topic','$risk','$criteria','$date')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New data inserted successfully");
document.location="engagement.php";
</script>