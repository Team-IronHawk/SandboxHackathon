<?php include('hdr1.php'); ?>
<?php include('dbconnect.php');?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="">
  <p>&nbsp;</p>
  <table width="200" border="1" align="center">
    <tr class="lhead" bgcolor="#663333" width="50%">
      <td>Date </td>
      <td>Strength</td>
      <td>Last Balance </td>
      <td>Today Credit </td>
      <td>Total</td>
      <td>Today Consumed </td>
      <td>End Balance </td>
    </tr>
	<?php
	$sql="select * from cadd where cid='".$_POST['cid']."' and cmt='".$_POST['cmt']."' and cyr='".$_POST['cyr']."' and schid='".$_POST['schid']."' ";
	$res=mysql_query($sql); 
	while($row=mysql_fetch_array($res))
	{
	$a1=$row['l3pbal'];
	$a2=$row['l3tc'];
	$tot=$a1+$a2;
	?>
		 <?php
  $m=0;
	while($row=mysql_fetch_array($res))
	{
	$style="dr";
	$style1="#FFFFCC";
	if($m % 2 != 0){
	$style="sr";
	$style1="#FFFFCC";
	}
	$m++;
	?>
    <tr bgcolor="<?php echo $style1?>"  onmouseover="MouseOver(this);" onmouseout="MouseOut(this);" class="ldata">
      <td class="<?php echo $style?>"><?php echo $row['cdt'];?></td>
      <td class="<?php echo $style?>"><?php echo $row['l3strength'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $row['l3pbal'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $row['l3tc'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $tot;?></td>
      <td class="<?php echo $style?>"><?php echo $row['l3cons'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $row['l3bal'];?>&nbsp;</td>
    </tr>
	<?php
	}
	}
	?>
  </table>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>
