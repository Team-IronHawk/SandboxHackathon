<?php  session_start();
$aduname=$_POST['aduname'];
$adpwd=$_POST['adpwd'];
if($aduname=="admin" && $adpwd=="admin")
{
$_SESSION['aduname']=$aduname;
$_SESSION['adpwd']=$adpwd;

header("location:beohome.php");
}
else
{
?>
<script>
alert("Invalid Login Details...Try Again...");
document.location="beologin.php"
</script>
<?php

}?>