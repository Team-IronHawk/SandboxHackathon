<?php include('dbconnect.php');?>
<?php
$cid=$_GET['cid'];
$sql="delete from comsumable where cid='$cid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("consumable Details Deleted successfully");
document.location="listconsumable.php";
</script>