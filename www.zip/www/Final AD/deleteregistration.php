
<?php include('dbconnect.php');?>
<?php
$regid=$_GET['regid'];
$sql="delete from registration where regid='$regid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("Registration Details Deleted successfully");
document.location="listregistration.php";
</script>