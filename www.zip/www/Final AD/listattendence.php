<?php include('hdr.php'); ?>
<?php include('dbconnect.php'); ?>
<?php
$sql="select st.*,sc.*,at.* from student st,school sc,attendence at where at.schid=sc.schid and at.studid=st.studid";
$res=mysql_query($sql);
?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="">
  <table width="480" height="71" border="1" align="center">
    <tr bgcolor="#663333" class="lhead">
      <td width="46">School name </td>
      <td width="50">Student name </td>
      <td width="29">Date</td>
      <td width="40">Month</td>
      <td width="30">Year</td>
      <td width="33">Level</td>
      <td width="33">Class</td>
      <td width="73">Attendence status </td>
      <td width="41">Update</td>
      <td width="41">Delete</td>
    </tr>
	<?php
	while($row=mysql_fetch_array($res))
	{
	?>
    <tr>
      <td><?php echo $row['schname']; ?>&nbsp;</td>
      <td><?php echo $row['nos']; ?>&nbsp;</td>
      <td><?php echo $row['atdt']; ?>&nbsp;</td>
      <td><?php echo $row['atmnth']; ?>&nbsp;</td>
      <td><?php echo $row['atyr']; ?>&nbsp;</td>
      <td><?php echo $row['level']; ?>&nbsp;</td>
      <td><?php echo $row['std']; ?>&nbsp;</td>
      <td><?php echo $row['atstatus']; ?>&nbsp;</td>
      <td align="center"><a href="editattendence.php?atid=<?php echo $row['atid'];?>"><img src="images/b_edit.png" /></a></td>
      <td align="center"><a href="deleteattendence.php"><img src="images/b_drop.png" /></a></td>
    </tr>
	<?php
	}
	?>
  </table>
    <p align="center"> <a href="newattendence.php"></a> </p>
    <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>
