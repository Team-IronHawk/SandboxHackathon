
<?php
					header('Content-Type: application/vnd.ms-word');
	header('Content-Disposition: attachment; filename=Expenditure_print.doc');

?>
<?php include('dbconnect.php');?>



<?php
$sql="select * from expenditure where schid='".$_POST['schid']."' and exmnth='".$_POST['exmnth']."' and exyr='".$_POST['exyr']."'";
$res=mysql_query($sql);
$sqlamt="select sum(amtpaid) as amt from expenditure where  schid='".$_POST['schid']."' and exmnth='".$_POST['exmnth']."' and exyr='".$_POST['exyr']."'";
$schid=$_POST['schid'];

$rt=mysql_query($sqlamt);
$tot=mysql_fetch_array($rt);

?>
<p>&nbsp;</p>
<form name="form1" method="post" action="">
<table width="800" border="1" align="center">
  <tr class="lhead"  width="50%" style="font-size:24px">
    
    <td>Expenditure Name</td>
    <td>Discription</td>
    <td>Date </td>
    <td>Month </td>
    <td>Year </td>
    <td>Amount To Be Paid</td>
    <td>Amount In Rupees </td>
    </tr>
  <?php
	while($row=mysql_fetch_array($res))
	{
	?>
  <tr  class="lrow">
   
    <td class="<?php echo $style?>"><?php echo $row['exname']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['discription']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['exdt']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['exmnth']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['exyr']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['amtpaid']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['amtrs']; ?>&nbsp;</td>
    </tr>
	<?php
	}
	?>
  <tr >
    <td  class="<?php echo $style?>" colspan="5" align="right">Total Amount: </td>
    
    <td class="<?php echo $style?>" ><?php echo $tot['amt'];?></td>
    <td>&nbsp;</td>
  </tr>
  	
</table>
 
</form>
