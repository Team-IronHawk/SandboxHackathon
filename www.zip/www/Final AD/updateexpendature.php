<?php include('dbconnect.php'); ?>
<?php
$exid=$_POST['exid'];
$schid=$_POST['schid'];
$exname=$_POST['exname'];
$discription=$_POST['discription'];
$exdt=$_POST['exdt'];
$exmnth=$_POST['exmnth'];
$exyr=$_POST['exyr'];
$amtpaid=$_POST['amtpaid'];
$amtrs=$_POST['amtrs'];
$sql="update expenditure set schid='$schid', exname='$exname', discription='$discription', exdt='$exdt', exmnth='$exmnth', exyr='$exyr', amtpaid='$amtpaid', amtrs='$amtrs' where exid='$exid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New expendature Details inseted successfully");
document.location="listexpendature.php";
</script>