<?php include('hdr1.php'); ?>
<?php include('dbconnect.php'); ?>
<?php
$sql="select * from school";
$res=mysql_query($sql);
?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="">
  <table width="200" border="1" align="center">
    <tr bgcolor="#663333" class="lhead" align="left">
      <td>Name of School </td>
      <td>School type</td>
      <td>School authority</td>
      <td><p>Date Of Establishment </p>      </td>
      <td>Date Of Registration </td>
      <td>School Address</td>
      <td>Place</td>
      <td>Taluk</td>
      <td>District</td>
      <td>Phone</td>
      <td>Update</td>
      <td>Delete</td>
    </tr>
	<?php
	while($row=mysql_fetch_array($res))
	{
	?>
    <tr class="ldata">
      <td><?php echo $row['schname']; ?>&nbsp;</td>
      <td><?php echo $row['schtype']; ?>&nbsp;</td>
      <td><?php echo $row['schauthority']; ?>&nbsp;</td>
      <td><?php echo $row['doe']; ?>&nbsp;</td>
      <td><?php echo $row['dor']; ?>&nbsp;</td>
      <td><?php echo $row['schaddress']; ?>&nbsp;</td>
      <td><?php echo $row['place']; ?>&nbsp;</td>
      <td><?php echo $row['taluk']; ?>&nbsp;</td>
      <td><?php echo $row['district']; ?>&nbsp;</td>
      <td><?php echo $row['schpno']; ?>&nbsp;</td>
      <td align="center"><a href="editschool.php?schid=<?php echo $row['schid'];?>"><img src="images/b_edit.png" /></a></td>
      <td align="center"><a href="deleteschool.php?schid=<?php echo $row['schid'];?>"><img src="images/b_drop.png" /></a></td>
    </tr>
	<?php 
	}
	?>
  </table>
  <p align="center"> <a href="newschool.php"></a></p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>

