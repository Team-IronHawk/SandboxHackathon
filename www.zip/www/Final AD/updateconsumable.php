<?php include('dbconnect.php'); ?>
<?php
$cid=$_POST['cid'];
$cname=$_POST['cname'];
$l1rps=$_POST['l1rps'];
$l2rps=$_POST['l2rps'];
$l3rps=$_POST['l3rps'];
$sql="update comsumable set cname='$cname',l1rps='$l1rps',l2rps='$l2rps',l3rps='$l3rps' where cid='$cid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New consumable details inseted successfully");
document.location="listconsumable.php";

</script>