<?php include('dbconnect.php'); ?>
<?php
$atid=$_POST['atid'];
$schid=$_POST['schid'];
$studid=$_POST['studid'];
$atdt=$_POST['atdt'];
$atmnth=$_POST['atmnth'];
$atyr=$_POST['atyr'];
$level=$_POST['level'];
$std=$_POST['std'];
$atstatus=$_POST['atstatus'];
$sql="insert into attendence values(null,'$schid','$studid','$atdt','$atmnth','$atyr','$level','$std','$atstatus')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New attendence inserted successfully");
document.location="listattendence.php";
</script>