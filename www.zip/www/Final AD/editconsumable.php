<?php include('hdr1.php');?>
<?php include('dbconnect.php');?>
<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<?php
$cid=$_GET['cid'];
$sql="select * from comsumable where cid='$cid'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?>
<form name="form1" method="post" action="updateconsumable.php">
  <p>&nbsp;</p>
  <table width="400" border="1" align="center">
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Consumable Name</td>
      <td bgcolor="#FFFFCC" class="ldata">
	       <script>
        function cnam()
        {
          var x=document.getElementById("cname");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*$/))
          {
            window.alert("Please Enter Characters Only");
            document.getElementById("cname").value="";
            document.form.cname.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.cname.focus();
          }
         }
      </script>
	  <input name="cid" type="hidden" id="cid" value="<?php echo $row['cid'];?>">
	  <input name="cname" type="text" id="cname" value="<?php echo $row['cname'];?>" required x-moz-errormessage="Please enter Expendature name" onblur="cnam()"style="width:183px"></td>
    </tr>
    <tr>
      <td  class="lhead" bgcolor="#663333" width="50%">Requirement Per Student Of Primary </td>
      <td bgcolor="#FFFFCC" class="ldata"><input name="l1rps"style="width:183px" type="text" id="l1rps" value="<?php echo $row['l1rps'];?>" required="1"></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Requirement Per Student Of Higher Primary </td>
      <td bgcolor="#FFFFCC" class="ldata"><input name="l2rps" type="text" id="l2rps" style="width:183px" value="<?php echo $row['l2rps'];?>" required="1"></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Requirement Per Student Of High School </td>
      <td bgcolor="#FFFFCC" class="ldata"><input name="l3rps" type="text" id="l3rps"style="width:183px" value="<?php echo $row['l3rps'];?>" required="1"></td>
    </tr>
    <tr align="center">
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset" class="button">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php');?>
