<?php include('hdr.php'); ?>
<?php include('dbconnect.php');?>
<?php
$atid=$_GET['atid'];
$sql="select * from attendence where atid='$atid'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?>
<form name="form1" method="post" action="updateattendence.php">
  <table width="200" border="1" align="center">
    <tr>
      <td>School Id </td>
      <td><label>
	  <input name="atid" type="hidden" id="atid" value="<?php echo $row['atid'];?>">
      <select name="schid" id="schid" required="1">
	    <?php 
		$sql1="select * from school";
		$res1=mysql_query($sql1);
		while($row1=mysql_fetch_array($res1))
		{
		?>
          <option value="<?php echo $row1['schid'];?>"> <?php echo $row1['schname']; ?> </option>
          <?php
		}
		?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td>Student Id </td>
      <td><label>
        <select name="studid" id="studid" required="1">
		  <?php 
		$sql1="select * from student";
		$res1=mysql_query($sql1);
		while($row1=mysql_fetch_array($res1))
		{
		?>
          <option value="<?php echo $row1['studid'];?>"> <?php echo $row1['nos']; ?> </option>
          <?php
		}
		?>
        </select>
      </label></td>
    </tr>
    <tr>
      <td>Date</td>
      <td><label>
        <select name="atdt" id="atdt" required="1">
          <?php
		$i=1;
do{
		?>
          <option value="<?php echo $i?>"><?php echo $i;?></option>
          <?php
		$i++;
		}
		while($i<32)
		
		?>
        </select>
      </label></td>
    </tr>
    <tr>
      <td>Month</td>
      <td><label>
        <select name="exmnth" id="exmnth">
          <option value="January">January</option>
          <option value="February">February</option>
          <option value="March">March</option>
          <option value="April">April</option>
          <option value="May">May</option>
          <option value="June">June</option>
          <option value="July">July</option>
          <option value="August">August</option>
          <option value="September">September</option>
          <option value="October">October</option>
          <option value="November">November</option>
          <option value="December">December</option>
        </select>
      </label></td>
    </tr>
    <tr>
      <td>Year</td>
      <td><label>
        <select name="atyr" id="atyr" required="1">
        <?php
		$y=2010;
do{
		?>
        <option value="<?php echo $y;?>"><?php echo $y;?></option>
        <?php
		$y++;
		}
		while($y<2051)
		
		?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td>Level</td>
      <td><label>
        <select name="level" id="level" required="1">
          <option value="Primary">Primary</option>
          <option value="Higher Primary">Higher Primary</option>
          <option value="High School">High School</option>
        </select>
      </label></td>
    </tr>
    <tr>
      <td>Class</td>
      <td><select name="class" id="class" required="1">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
        </select>&nbsp;</td>
    </tr>
    <tr>
      <td>Attendence Status </td>
      <td><input name="atstatus" type="text" id="atstatus" value="<?php echo $row['atstatus'];?>" required="1"></td>
    </tr>
    <tr>
      <td><label>
        <input type="submit" name="Submit" value="Submit">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>
