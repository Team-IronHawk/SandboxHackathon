<?php include('dbconnect.php');?>
<?php
$staffid=$_GET['staffid'];
$sql="delete from staff where staffid='$staffid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("Staff Details Deleted successfully");
document.location="liststaff.php";
</script>