<?php include('hdr.php'); ?>
<?php include('dbconnect.php');?>
<?php
$dcid=$_GET['dcid'];
$sql="select * from cadd where dcid='$dcid'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?>
<form name="form1" method="post" action="updateadd.php">
  <table width="200" border="1" align="center">
    <tr>
      <td>consumable id </td>
      <td><label>
	   <input name="dcid" type="hidden" id="dcid" value="<?php echo $row['dcid'];?>">
      <select name="cid" id="cid">
	  <?php 
	  $sql1="select * from comsumable";
	  $res1=mysql_query($sql1);
	  while($row1=mysql_fetch_array($res1))
	  {
	  ?>
	  <option selected="selected" value="<?php echo $row1['cid'];?>"><?php echo $row1['cid'];?></option>
	  <?php
	  }
	  ?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td>school id </td>
      <td><label>
      <select name="schid" id="schid">
	  <?php 
	  $sql2="select * from school";
	  $res2=mysql_query($sql2);
	  while($row2=mysql_fetch_array($res2))
	  {
	  ?>
	  <option selected="selected" value="<?php echo $row2['schid'];?>"><?php echo $row2['schname'];?></option>
	  <?php
	  }
	  ?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td>Date</td>
      <td><label>
        <select name="cdt" id="cdt" required="1">
          <?php
		$i=1;
        do{
		?>
          <option value="<?php echo $i?>"><?php echo $i;?></option>
          <?php
		$i++;
		}
		while($i<32)
		
		?>
        </select>
      </label></td>
    </tr>
    <tr>
      <td>Month</td>
      <td><label>
        <select name="cmt" id="cmt">
          <option value="January">January</option>
          <option value="February">February</option>
          <option value="March">March</option>
          <option value="April">April</option>
          <option value="May">May</option>
          <option value="June">June</option>
          <option value="July">July</option>
          <option value="August">August</option>
          <option value="September">September</option>
          <option value="October">October</option>
          <option value="November">November</option>
          <option value="December">December</option>
        </select>
      </label></td>
    </tr>
    <tr>
      <td>Year</td>
      <td><select name="cyr" id="cyr" required="1">
          <?php
		$y=2010;
        do{
		?>
          <option value="<?php echo $y;?>"><?php echo $y;?></option>
          <?php
		$y++;
		}
		while($y<2051)
		
		?>
      </select></td>
    </tr>
   <tr>
      <td>level1 previous balance</td>
      <td><label>
	  <input name="l1pbal" type="text" id="l1pbal" value="<?php echo $row['l1pbal'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level2 previous balance</td>
      <td><label>
      <input name="l2pbal" type="text" id="l2pbal" value="<?php echo $row['l2pbal'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level3 previous balance </td>
      <td><label>
      <input name="l3pbal" type="text" id="l3pbal" value="<?php echo $row['l3pbal'];?>">
      </label></td>
    </tr>
	 <tr>
      <td>level1 today credit</td>
      <td><label>
        <input name="l1tc" type="text" id="l1tc" value="<?php echo $row['l1tc'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level2 today credit</td>
      <td><label>
      <input name="l2tc" type="text" id="l2tc" value="<?php echo $row['l2tc'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level3 today credit</td>
      <td><label>
      <input name="l3tc" type="text" id="l3tc" value="<?php echo $row['l3tc'];?>">
      </label></td>
    </tr>
	<tr>
      <td>level1 strength </td>
      <td><label>
      <input name="l1strength" type="text" id="l1strength" value="<?php echo $row['l1strength'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level2 strength </td>
      <td><label>
        <input name="l2strength" type="text" id="l2strength" value="<?php echo $row['l2strength'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level3 strength </td>
      <td><label>
        <input name="l3strength" type="text" id="l3strength" value="<?php echo $row['l3strength'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level1 consumed </td>
      <td><label>
        <input name="l1cons" type="text" id="l1cons" value="<?php echo $row['l1cons'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level2 consumed </td>
      <td><label>
      <input name="l2cons" type="text" id="l2cons" value="<?php echo $row['l2cons'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level3 consumed </td>
      <td><label>
      <input name="l3cons" type="text" id="l3cons" value="<?php echo $row['l3cons'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level1 balance</td>
      <td><label>
        <input name="l1bal" type="text" id="l1bal" value="<?php echo $row['l1bal'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level2 balance</td>
      <td><label>
      <input name="l2bal" type="text" id="l2bal" value="<?php echo $row['l2bal'];?>">
      </label></td>
    </tr>
    <tr>
      <td>level3 balance </td>
      <td><label>
      <input name="l3bal" type="text" id="l3bal" value="<?php echo $row['l3bal'];?>">
      </label></td>
    </tr>
    <tr>
      <td><label>
        <input type="submit" name="Submit" value="Submit">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset">
      </label></td>
    </tr>
  </table>
</form>
<?php include('ftr.php'); ?>

