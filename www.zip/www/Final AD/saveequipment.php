<?php include('dbconnect.php'); ?>
<?php
$eid=$_POST['eid'];
$schid=$_POST['schid'];
$ename=$_POST['ename'];
$etype=$_POST['etype'];
$capacity=$_POST['capacity'];
$dop=$_POST['dop'];
$cndition=$_POST['cndition'];
$sql="insert into equipment values(null,'$schid','$ename','$etype','$capacity','$dop','$cndition')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New equipment Details inseted successfully");
document.location="listequipment.php";
</script>