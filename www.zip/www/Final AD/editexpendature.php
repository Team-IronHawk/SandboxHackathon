<?php include('schsv.php'); ?>
<?php include('hdr.php');?>
<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<?php include('dbconnect.php'); ?>
<?php
$exid=$_GET['exid'];
$sql="select * from expenditure where exid='$exid'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?>
<form name="form1" method="post" action="updateexpendature.php">
  <p>&nbsp;</p>
  <table width="400" border="1" align="center">
    <tr>
	<?php 
		$schid=$_SESSION['schid'];
		$sql1="select * from school where schid='$schid'";
		$res1=mysql_query($sql1);
		$row1=mysql_fetch_array($res1);
		?>
      
        <input name="schid" type="hidden" value="<?php echo $row1['schid'];?> " id="schid" />
      <td class="lhead" bgcolor="#663333" width="50%">Expendature Name </td>
      <td bgcolor="#FFFFCC" class="ldata">
	     <script>
        function nam()
        {
          var x=document.getElementById("exname");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*$/))
          {
            window.alert("Please Enter Characters Only");
            document.getElementById("exname").value="";
            document.form.exname.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.exname.focus();
          }
         }
      </script>
	  <input name="exname" type="text" id="exname" value="<?php echo $row['exname'];?>" required x-moz-errormessage="Please enter Expendature name" onblur="nam()" style="width:183px"></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Discription</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <textarea name="discription" id="discription" required="1" style="width:183px"><?php echo $row['discription'];?></textarea>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Date</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <select name="exdt" id="exdt" required x-moz-errormessage="Please Select Date"  style="width:190px">
        <option selected="selected" value="">Select</option>
		<?php
		$i=1;
do{
		?>
		
        <option value="<?php echo $i?>"><?php echo $i;?></option>
        <?php
		$i++;
		}
		while($i<32)
		
		?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Month</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <select name="exmnth" id="exmnth"  style="width:190px" required x-moz-errormessage="Please Select Month">
		<option selected="selected" value="">Select</option>
          <option value="JANUARY">JANUARY</option>
		  <option value="FEBRUARY">FEBRUARY</option>
		  <option value="MARCH">MARCH</option>
		  <option value="APRIL">APRIL</option>
		  <option value="MAY">MAY</option>
		  <option value="JUNE">JUNE</option>
		  <option value="JULY">JULY</option>
		  <option value="AUGUST">AUGUST</option>
		  <option value="SEPTEMBER">SEPTEMBER</option>
		  <option value="OCTOBER">OCTOBER</option>
		  <option value="NOVEMBER">NOVEMBER</option>
		  <option value="DECEMBER">DECEMBER</option>
        </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Year</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <select name="exyr" id="exyr"  style="width:190px" required x-moz-errormessage="Please Select Year">
        <?php
		$y=2010;
do{
		?>
		<option selected="selected" value="">Select</option>
        <option value="<?php echo $y;?>"><?php echo $y;?></option>
        <?php
		$y++;
		}
		while($y<2051)
		
		?>
        </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Amount To Be Paid </td>
      <td bgcolor="#FFFFCC" class="ldata">
	  <script>
        function ap()
        {
          var x=document.getElementById("amtpaid");
          if(!x.value.match(/^[0-9]+$/))
          {
            window.alert("Please enter proper amount");
            document.getElementById("amtpaid").value="";
            document.form.amtpaid.focus();
           }
         }
      </script>
	  <input name="amtpaid" type="text" id="amtpaid" value="<?php echo $row['amtpaid'];?>" maxlength="5" required x-moz-errormessage="Please enter proper amount" onblur="ap()" style="width:183px"></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Amount In Words </td>
      <td bgcolor="#FFFFCC" class="ldata">  
	  <script>
        function apw()
        {
          var x=document.getElementById("amtrs");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*$/))
          {
            window.alert("Please enter amount in words");
            document.getElementById("amtrs").value="";
            document.form.amtrs.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.amtrs.focus();
          }
         }
      </script>
	  <input name="amtrs" type="text" id="amtrs" value="<?php echo $row['amtrs'];?>" required x-moz-errormessage="Please enter amount in words" onblur="apw()" style="width:183px" /></td>
    </tr>
    <tr bgcolor="#FFFFCC" class="ldata" align="center">
      <td><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset" class="button">
      </label></td>
    </tr>
  </table>
  -
  <p>&nbsp;</p>
</form>
<?php include('ftr.php');?>