<?php include('hdr.php'); ?>
<?php include('dbconnect.php');?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="saveadd.php">
  <table width="200" border="1" align="center">
   	<tr>
      <td bgcolor="#663333" class="lhead">Level 1 Previous Balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
	  <input name="dcid" type="hidden" id="dcid" value="<?php echo $_POST['dcid'];?>">
	   <input name="cid" type="hidden" id="cid" value="<?php echo $_POST['cid'];?>">
	    <input name="schid" type="hidden" id="schid" value="<?php echo $_POST['schid'];?>">
		 <input name="cdt" type="hidden" id="cdt" value="<?php echo $_POST['cdt'];?>">
		 <input name="cmt" type="hidden" id="cmt" value="<?php echo $_POST['cmt'];?>">
		 <input name="cyr" type="hidden" id="cyr" value="<?php echo $_POST['cyr'];?>">
	   <input name="l1pbal" type="text" id="l1pbal">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 2 Previous Balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l2pbal" tdype="text" id="l2pbal"> 
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 3 Previous Balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l3pbal" tdype="text" id="l3pbal">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 1 Today Credit </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l1tc" tdype="text" id="l1tc">
      </label></td>
    </tr>
    <tr>
     <td bgcolor="#663333" class="lhead">Level 2 Today Credit </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l2tc" tdype="text" id="l2tc">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 3 Today Credit </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l3tc" tdype="text" id="l3tc">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 1 Strength </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l1strength" type="text" id="l1strength">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 2 Strength </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l2strength" type="text" id="l2strength">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 3 Strength </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l3strength" type="text" id="l3strength">
      </label></td>
    </tr>
    <tr>
     <td bgcolor="#663333" class="lhead">Level 1 Consumed </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l1cons" type="text" id="l1cons">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 2 Consumed </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l2cons" type="text" id="l2cons">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 3 Consumed </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l3cons" type="text" id="l3cons">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 1 balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l1bal" type="text" id="l1bal">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 2 balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l2bal" type="text" id="l2bal">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 3 balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l3bal" type="text" id="l3bal">
      </label></td>
    </tr>
    <tr>
      <td><label>
        <input type="submit" name="Submit" value="Submit">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset">
      </label></td>
    </tr>
  </table>
</form>
<?php include('ftr.php'); ?>
