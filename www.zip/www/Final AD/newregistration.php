<?php include('hdr1.php'); ?>
<?php include('dbconnect.php');?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="saveregistration.php">
  <p>&nbsp;</p>
  <table width="400" border="1" align="center">
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Registration Id </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="regid" type="text" id="regid" style="width:183px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">School Id </td>
      <td bgcolor="#FFFFCC" class="ldata"><label><select name="schid" id="schid" style="width:190px">
          <?php 
		$sql="select * from school";
		$res=mysql_query($sql);
		while($row=mysql_fetch_array($res))
		{
		?>
          <option value="<?php echo $row['schid'];?>"> <?php echo $row['schname']; ?> </option>
          <?php
		}
		?>
        </select></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Username</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="scuname" type="text" id="scuname" style="width:183px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Password</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="scpwd" type="text" id="scpwd" style="width:183px">
      </label></td>
    </tr>
    <tr align="center" bgcolor="#FFFFCC" class="ldata">
      <td><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset" class="button">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>