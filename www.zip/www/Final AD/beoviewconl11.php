
<?php include('hdr1.php'); ?>
<?php include('dbconnect.php');?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="beoviewconl12.php">
  <table width="400" border="1" align="center">
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Select School Name </td>
      <td bgcolor="#FFFFCC" class="ldata"><select name="schid" id="schid" style="width:190px" required x-moz-errormessage="Please Select School">
         <option selected="selected" value="">Select</option>
		  <?php 
		$sql="select * from school";
		$res=mysql_query($sql);
		while($row=mysql_fetch_array($res))
		{
		?>
          <option value="<?php echo $row['schid'];?>"> <?php echo $row['schname']; ?> </option>
          <?php
		}
		?>
        </select>
        &nbsp;</td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Select Consumable </td>
      <td bgcolor="#FFFFCC" class="ldata"><select name="cid" id="cid" style="width:190px" required x-moz-errormessage="Please Select Consumable">
	  <option selected="selected" value="">Select</option>
          <?php 
		$sql="select * from comsumable";
		$res=mysql_query($sql);
		while($row=mysql_fetch_array($res))
		{
		?>
          <option value="<?php echo $row['cid'];?>"> <?php echo $row['cname']; ?> </option>
          <?php
		}
		?>
        </select>
        &nbsp;</td>
    </tr>

    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Select  Month </td>
      <td bgcolor="#FFFFCC" class="ldata"><select name="cmt" id="cmt" style="width:190px" required x-moz-errormessage="Please Select Month">
	  <option selected="selected" value="">Select</option>
          <option value="JANUARY">JANUARY</option>
          <option value="FEBRUARY">FEBRUARY</option>
          <option value="MARCH">MARCH</option>
          <option value="APRIL">APRIL</option>
          <option value="MAY">MAY</option>
          <option value="JUNE">JUNE</option>
          <option value="JULY">JULY</option>
          <option value="AUGUST">AUGUST</option>
          <option value="SEPTEMBER">SEPTEMBER</option>
          <option value="OCTOBER">OCTOBER</option>
          <option value="NOVEMBER">NOVEMBER</option>
          <option value="DECEMBER">DECEMBER</option>
        </select>
        &nbsp;</td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Select Year </td>
      <td bgcolor="#FFFFCC" class="ldata"><select name="cyr" id="cyr" required x-moz-errormessage="Please Select Year" style="width:190px">
          <option selected="selected" value="">Select</option>
		  <?php
		$y=2010;
do{
		?>
          <option value="<?php echo $y;?>"><?php echo $y;?></option>
          <?php
		$y++;
		}
		while($y<2051)
		
		?>
        </select>
        &nbsp;</td>
    </tr>
    <tr  align="center">
      <td bgcolor="#FFFFCC" class="ldata" colspan="2"><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
    </tr>
  </table>
</form>
<?php include('ftr.php'); ?>
