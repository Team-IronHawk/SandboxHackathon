<?php
session_start();
if(!(isset($_SESSION['schid'])) || ($_SESSION['schid'] == ""))
{
	?>
		<script>
			alert('Your session has been expired');
			document.location='index.html';
		</script>
	<?php
}
?>