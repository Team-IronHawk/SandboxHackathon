<?php include('hdr.php');?>
<?php include('dbconnect.php');?>
<script>
function startCalc()

{
interval = setInterval("calc()",1);
}
function calc()
{
 cls = document.form.std.value;
 
if(cls>=1&&cls<6)
{

document.form.level.value ='PRIMARY';
}
else if(cls>=6&&cls<8)
{
document.form.level.value ='HIGHER PRIMARY';
}
else 
{
document.form.level.value ='HIGH SCHOOL';
}

}

function stopCalc(){
clearInterval(interval);}

</script>
<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="CalendarControl.css" />
<script language="JavaScript" src="CalendarControl.js" type="text/javascript"></script>

<?php include('dbconnect.php');?>
<?php
$studid=$_GET['studid'];
$sql="select * from student where studid='$studid'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?>
<form name="form" method="post" action="updatestudent.php">
  <table width="400" border="1" align="center">
    <tr>
	<?php 
		$schid=$_SESSION['schid'];
		$sql1="select * from school where schid='$schid'";
		$res1=mysql_query($sql1);
		$row1=mysql_fetch_array($res1);
		?>
      
        <input name="schid" type="hidden" value="<?php echo $row1['schid'];?> " id="schid" />
      <td class="lhead" bgcolor="#663333" width="50%">Name Of Student </td>
      <td bgcolor="#FFFFCC" class="ldata">
	  <script>
        function ns()
        {
          var x=document.getElementById("nos");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*$/))
          {
            window.alert("Please Enter Characters Only");
            document.getElementById("nos").value="";
            document.form.nos.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.nos.focus();
          }
         }
      </script>
	  <label>
	  <input name="nos" type="text" id="nos"m value="<?php echo $row['nos'];?>" required x-moz-errormessage="Please enter student name" onblur="ns()" style="width:189px"/>
	  </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Gender</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="gender" type="radio" value="Male" id="gender" checked="checked" />
        Male 
        &nbsp; &nbsp; &nbsp;<input name="gender" type="radio" value="Female" id="radio" />
        Female
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Age</td>
      <td bgcolor="#FFFFCC" class="ldata">
	     <script>
        function ag()
        {
          var x=document.getElementById("age");
          if(!x.value.match(/^[0-9]{2}$/))
          {
            window.alert("Please Enter Proper Age");
            document.getElementById("age").value="";
            document.form.age.focus();
           }
         }
      </script>
	  <label>
      <input name="age" type="text" id="age" value="<?php echo $row['age'];?>" required x-moz-errormessage="Please enter age" onblur="ag()" style="width:189px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Standard</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <select name="std" id="std" style="width:190px" onFocus="startCalc();" required x-moz-errormessage="Please Select Stanadard">
	   <option selected="selected" value="">Select</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Level</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
       <input name="level" type="text" id="level" onFocus="startCalc();" onBlur="stopCalc();" style="width:189px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Date Of Birth </td>
      <td><label>
      <input name="dob" type="text" id="dob" onfocus="showCalendarControl(this)" value="<?php echo $row['dob'];?>" style="width:189px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Annual Income </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="annualincome" type="text" id="annualincome" value="<?php echo $row['annualincome'];?>" rquired="1" style="width:189px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Caste</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="caste" type="text" id="caste" value="<?php echo $row['caste'];?>" rquired="1"  style="width:189px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Category</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <select name="category" id="category" style="width:190px"  required x-moz-errormessage="Please Select Category">
	  <option selected="selected" value="">Select</option>
        <option value="S.C.">S.C.</option>
        <option value="S.T.">S.T.</option>
        <option value="Minorities">Minorities</option>
        <option value="Others">Others</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td height="30" class="lhead" bgcolor="#663333" width="50%">Physical Disable </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="phydisable" type="radio" value="yes"  />
      Yes
	  &nbsp; &nbsp; &nbsp; 
      <input name="phydisable" type="radio" value="no" checked="checked"/>
      No</label></td>
    </tr>
    <tr  bgcolor="#FFFFCC" class="ldata" align="center">
      <td height="33"><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset" class="button">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php');?>
