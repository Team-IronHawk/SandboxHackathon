<?php include('hdr.php'); ?>
<?php include('dbconnect.php');?>
<form name="form1" method="post" action="cadd2.php">
  <table width="200" border="1" align="center">
    <tr>
      <td>consumable id </td>
      <td><label>
      <select name="cid" id="cid">
	   <?php 
	  $sql="select * from comsumable";
	  $res=mysql_query($sql);
	  while($row=mysql_fetch_array($res))
	  {
	  ?>
	  <option selected="selected" value="<?php echo $row['cid'];?>"><?php echo $row['cname'];?></option>
	  <?php
	  }
	  ?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td>school id </td>
      <td><label>
      <select name="schid" id="schid">
	   <?php 
	  $sql="select * from school";
	  $res=mysql_query($sql);
	  while($row=mysql_fetch_array($res))
	  {
	  ?>
	  <option selected="selected" value="<?php echo $row['schid'];?>"><?php echo $row['schname'];?></option>
	  <?php
	  }
	  ?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td>Date</td>
      <td><label>
        <select name="cdt" id="cdt" required="1">
          <?php
		$i=1;
        do{
		?>
          <option value="<?php echo $i?>"><?php echo $i;?></option>
          <?php
		$i++;
		}
		while($i<32)
		
		?>
        </select>
      </label></td>
    </tr>
    <tr>
      <td>Month</td>
      <td><label>
        <select name="cmt" id="cmt">
          <option value="January">January</option>
          <option value="February">February</option>
          <option value="March">March</option>
          <option value="April">April</option>
          <option value="May">May</option>
          <option value="June">June</option>
          <option value="July">July</option>
          <option value="August">August</option>
          <option value="September">September</option>
          <option value="October">October</option>
          <option value="November">November</option>
          <option value="December">December</option>
        </select>
      </label></td>
    </tr>
    <tr>
      <td>Year</td>
      <td><select name="cyr" id="cyr" required="1">
          <?php
		$y=2010;
        do{
		?>
          <option value="<?php echo $y;?>"><?php echo $y;?></option>
          <?php
		$y++;
		}
		while($y<2051)
		
		?>
      </select></td>
    </tr>
    <tr>
      <td><label>
        <input type="submit" name="Submit" value="Submit">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset">
      </label></td>
    </tr>
  </table>
</form>
<?php include('ftr.php'); ?>
