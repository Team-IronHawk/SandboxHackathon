<?php include('hdr1.php');?>
<?php include('dbconnect.php');?>
<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<?php
$staffid=$_GET['staffid'];
$sql="select * from staff where staffid='$staffid'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?>
<form name="form1" method="post" action="updatestaff.php">
  <table width="400" border="1" align="center">
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">School Id </td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
      <input name="staffid" type="hidden" id="staffid" value="<?php echo $row['staffid'];?>" style="width:178px">
	  <select name="schid" id="schid"  style="width:178px">
	   <?php 
	  $sql1="select * from school";
	  $res1=mysql_query($sql1);
	  while($row1=mysql_fetch_array($res1))
	  {
	  ?>
	  <option value="<?php echo $row1['schid'];?>"><?php echo $row1['schname'];?></option>
	  <?php
	  }
	  ?>
      </select>
      </label></td>
    </tr>
	<script>
        function n()
        {
          var x=document.getElementById("name");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*$/))
          {
            window.alert("Please Enter Characters Only");
            document.getElementById("name").value="";
            document.form.name.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.name.focus();
          }
         }
      </script>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Name</td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
      <input name="name" type="text" id="name" value="<?php echo $row['name'];?>" onblur="n()" required="1" style="width:183px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Staff type </td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
      <select name="stafftype" id="stafftype" style="width:178px">
        <option value="Teaching">Teaching</option>
        <option value="Non-teaching">Non-teaching</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Designation</td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
      <select name="designation" id="designation" style="width:178px">
        <option value="Principal">Principal</option>
        <option value="H.O.D">H.O.D</option>
        <option value="Lecture">Lecture</option>
        <option value="Clerk">Clerk</option>
        <option value="Librarian">Librarian</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Date of joining </td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
      <input name="doj" type="text" id="doj" value="<?php echo $row['doj'];?>" style="width:183px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Experience</td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
      <input name="experience" type="text" id="experience" value="<?php echo $row['experience'];?>" style="width:183px">
      </label></td>
    </tr>
	<script>
        function p()
        {
          var x=document.getElementById("phno");
          if(!x.value.match(/^[0-9]{10}$/))
          {
            window.alert("Please Enter Numbers Only");
            document.getElementById("phno").value="";
            document.form.phno.focus();
           }
         }
      </script>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Phone number </td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
      <input name="phno" type="text" id="phno" value="<?php echo $row['phno'];?>" onblur="p()" required="1" style="width:183px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Address</td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
        <textarea name="addr" id="addr" style="width:183px"><?php echo $row['addr'];?></textarea>
      </label></td>
    </tr>
    <tr>
      <td><label>
        <input type="submit" name="Submit" value="Submit">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset">
      </label></td>
    </tr>
  </table>
</form>
<?php include('ftr.php');?>