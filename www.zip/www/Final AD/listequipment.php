<?php include('schsv.php'); ?>
<?php include('hdr.php');?>
<?php include('dbconnect.php'); ?>
<?php
$sql="select eq.*,sc.* from equipment eq,school sc where eq.schid=sc.schid";
$res=mysql_query($sql);
?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="">
  <table width="200" border="1" align="center">
    <tr bgcolor="#663333" class="lhead">
      <td>School Name </td>
      <td>Equipment name </td>
      <td>Equipment type </td>
      <td>Capacity</td>
      <td>Date of purchase </td>
      <td>Condition</td>
      <td>Update</td>
      <td>Delete</td>
    </tr>
	<?php
	while($row=mysql_fetch_array($res))
	{
	?>
    <tr class="ldata">
      <td><?php echo $row['schname']; ?>&nbsp;</td>
      <td><?php echo $row['ename']; ?>&nbsp;</td>
      <td><?php echo $row['etype']; ?>&nbsp;</td>
      <td><?php echo $row['capacity']; ?>&nbsp;</td>
      <td><?php echo $row['dop']; ?>&nbsp;</td>
      <td><?php echo $row['cndition']; ?>&nbsp;</td>
      <td align="center"><a href="editequipment.php?eid=<?php echo $row['eid'];?>"><img src="images/b_edit.png" /></a></td>
      <td align="center"><a href="deleteequipment.php?eid=<?php echo $row['eid'];?>"><img src="images/b_drop.png" /></a></td>
    </tr>
	<?php
	}
	?>
  </table>
  <p align="center"> <a href="newequipment.php"></a></p>
</form>
<?php include('ftr.php');?>
