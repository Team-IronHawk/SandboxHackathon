<?php include('hdr1.php'); ?>
<?php include('dbconnect.php'); ?>
<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<?php
$regid=$_GET['regid'];
$sql="select * from registration where regid='$regid'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?>
<form name="form1" method="post" action="updateregistration.php">
  <p>&nbsp;</p>
  <table width="400" border="1" align="center">
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Registration Id </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="regid" type="text" id="regid" style="width:183px" value="<?php echo $row['regid'];?>">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">School Id </td>
      <td bgcolor="#FFFFCC" class="ldata"><select name="schid" id="schid" style="width:190px">
        <?php 
		$sql1="select * from school";
		$res1=mysql_query($sql1);
		while($row1=mysql_fetch_array($res1))
		{
		?>
        <option value="<?php echo $row1['schid'];?>"> <?php echo $row1['schname']; ?> </option>
        <?php
		}
		?>
      </select>        &nbsp;</td>
    </tr>
    <tr>
      <td  class="lhead" bgcolor="#663333" width="50%">Username</td>
      <td bgcolor="#FFFFCC" class="ldata"><input name="scuname" type="text" id="uname" style="width:183px" value="<?php echo $row['scuname'];?>"></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Password</td>
      <td bgcolor="#FFFFCC" class="ldata"><input name="scpwd" type="text" id="pwd" style="width:183px" value="<?php echo $row['scpwd'];?>"></td>
    </tr>
    <tr bgcolor="#FFFFCC" class="ldata">
      <td><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset" class="button">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>