<?php include('dbconnect.php');?>
<?php
$eid=$_GET['eid'];
$sql="delete from equipment where eid='$eid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("eqiupment Details Deleted successfully");
document.location="listequipment.php";
</script>