<?php include('hdr1.php'); ?>
<?php include('dbconnect.php'); ?>
<?php 
$sql="select r.*,s.*  from registration r,school s where r.schid=s.schid";
$res=mysql_query($sql);
?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="">
  <table width="200" border="1" align="center">
    <tr bgcolor="#663333" class="lhead">
      <td>School Id </td>
      <td>Username</td>
      <td>Password</td>
      <td>Update</td>
      <td>Delete</td>
    </tr>
	<?php
	while($row=mysql_fetch_array($res))
	{
	?>
    <tr class="ldata">
      <td><?php echo $row['schname']; ?>&nbsp;</td>
      <td><?php echo $row['scuname']; ?>&nbsp;</td>
      <td><?php echo $row['scpwd']; ?>&nbsp;</td>
      <td align="center"><a href="editregistration.php?regid=<?php echo $row['regid']; ?>"><img src="images/b_edit.png" /></a></td>
      <td align="center"><a href="deleteregistration.php?regid=<?php echo $row['regid'];?>"><img src="images/b_drop.png" /></a></td>
    </tr>
	<?php 
	}
	?>
    </table>
	<p align="center"><a href="newregistration.php">New Registration</a> </p>
</form>
<?php include('ftr.php'); ?>