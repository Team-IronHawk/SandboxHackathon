<?php include('dbconnect.php');?>
<?php
$studid=$_GET['studid'];
$sql="delete from student where studid='$studid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("Student Details Deleted successfully");
document.location="liststudent.php";
</script>