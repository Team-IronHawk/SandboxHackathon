<?php include('schsv.php'); ?>
<?php include('hdr.php');?>
<?php include('dbconnect.php');?>
<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="CalendarControl.css" />
<script language="JavaScript" src="CalendarControl.js" type="text/javascript"></script>
<?php include('dbconnect.php');?>
<form name="form1" method="post" action="saveequipment.php">
  <table width="400" border="1" align="center">
    <tr>
	<?php 
		$schid=$_SESSION['schid'];
		$sql="select * from school where schid='$schid'";
		$res=mysql_query($sql);
		$row=mysql_fetch_array($res);
		?>
      
        <input name="schid" type="hidden" value="<?php echo $row['schid'];?> " id="schid" />
      <td class="lhead" bgcolor="#663333" width="50%">Equipment Name </td>
      <td bgcolor="#FFFFCC" class="ldata">
	      <script>
        function enam()
        {
          var x=document.getElementById("ename");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*$/))
          {
            window.alert("Please Enter Characters Only");
            document.getElementById("ename").value="";
            document.form.ename.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.ename.focus();
          }
         }
      </script>
	  <label>
        <input name="ename" type="text" id="ename" required x-moz-errormessage="Please enter Expendature name" onblur="enam()" style="width:183px">
      </label></td>
    </tr>
	 <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Equipment Ttype </td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><label>
      <select name="etype" id="etype" style="width:190px" required x-moz-errormessage="Please Select Equipment">
	  <option selected="selected" value="">Select</option>
        <option value="PLASTIC">PLASTIC</option>
        <option value="STEEL">STEEL</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Capacity</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="capacity" type="text" id="capacity" required="1" style="width:183px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Date Of Purchase </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="dop" type="text" id="dop" onfocus="showCalendarControl(this)" style="width:183px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Condition</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="cndition" type="text" id="cndition" required="1" style="width:183px">
      </label></td>
    </tr>
    <tr align="center" bgcolor="#FFFFCC" class="ldata">
      <td><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset" class="button">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php');?>
