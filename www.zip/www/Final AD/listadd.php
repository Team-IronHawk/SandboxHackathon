<?php include('hdr.php'); ?>
<?php include('dbconnect.php'); ?>
<?php
$sql="select ca.*,cn.*,sc.* from cadd ca,comsumable cn,school sc where ca.cid=cn.cid and ca.schid=sc.schid";
$res=mysql_query($sql);
?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="">
  <table width="200" border="1" align="center">
    <tr bgcolor="#663333" class="lhead">
      <td>Consumable id </td>
      <td>Select school </td>
      <td>Level1 previous balance </td>
	  <td>Level2 previous balance </td>
	  <td>Level3 previous balance </td>
	  <td>Level1 today credit</td>
	  <td>Level2 today credit</td>
	  <td>Level3 today credit</td>
      <td>Level1 strength </td>
      <td>Level2 strength </td>
      <td>Level3 strength </td>
      <td>Level1 consumed </td>
      <td>Level2 consumed </td>
      <td>Level3 consumed </td>
      <td>Level1 balance </td>
      <td>Level2 balance </td>
      <td>Level3 balance </td>
      <td>Update</td>
      <td>Delete</td>
    </tr>
	<?php
	while($row=mysql_fetch_array($res))
	{
	?>
    <tr class="ldata">
      <td><?php  echo $row['cname']; ?>&nbsp;</td>
      <td><?php  echo $row['schname']; ?>&nbsp;</td>
  	  <td><?php  echo $row['l1pbal']; ?>&nbsp;</td>
      <td><?php  echo $row['l2pbal']; ?>&nbsp;</td>
      <td><?php  echo $row['l3pbal']; ?>&nbsp;</td>
	  <td><?php  echo $row['l1tc']; ?>&nbsp;</td>
      <td><?php  echo $row['l2tc']; ?>&nbsp;</td>
      <td><?php  echo $row['l3tc']; ?>&nbsp;</td>
      <td><?php  echo $row['l1strength']; ?>&nbsp;</td>
      <td><?php  echo $row['l2strength']; ?>&nbsp;</td>
      <td><?php  echo $row['l3strength']; ?>&nbsp;</td>
      <td><?php  echo $row['l1cons']; ?>&nbsp;</td>
      <td><?php  echo $row['l2cons']; ?>&nbsp;</td>
      <td><?php  echo $row['l3cons']; ?>&nbsp;</td>
      <td><?php  echo $row['l1bal']; ?>&nbsp;</td>
      <td><?php  echo $row['l2bal']; ?>&nbsp;</td>
      <td><?php  echo $row['l3bal']; ?>&nbsp;</td>
      <td align="center"><a href="editadd.php?dcid=<?php echo $row['dcid'];?>"><img src="images/b_edit.png" /></a></td>
      <td align="center"><a href="deleteadd.php?dcid=<?php echo $row['dcid'];?>"><img src="images/b_drop.png" /></a></td>
    </tr>
  <?php
  }
  ?>
  </table>
   <p align="center"> <a href="cadd1.php"></a></p>
   <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>

