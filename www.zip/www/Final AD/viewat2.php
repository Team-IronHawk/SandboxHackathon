<?php include('schsv.php'); ?>
<?php include('dbconnect.php');?>
<?php include('hdr.php');?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="at3.php">
  <p>&nbsp;</p>
  <table width="400" border="1" align="center">
    <tr  class="lhead" bgcolor="#663333">
      <td>Sl No </td>
      <td>Student Name </td>
      <td>Status</td>
    </tr>
	<?php 
	$i=1;
	$sql="select s.*,a.* from student s,attendence a where s.schid='".$_POST['schid']."' and s.std='".$_POST['std']."' and a.atdt='".$_POST['atdt']."' and  a.atmnth='".$_POST['atmnth']."' and a.atyr='".$_POST['atyr']."' and a.studid=s.studid";
$res=mysql_query($sql);
while($row=mysql_fetch_array($res))
	{
	 $style="dr";
	$style1="#FFFFCC";
	if($m % 2 != 0){
	$style="sr";
	$style1="#FFFFCC";
	}
	$m++;
	?>
    <tr  bgcolor="<?php echo $style1?>"  onmouseover="MouseOver(this);" onmouseout="MouseOut(this);" class="lrow">
	<input type="hidden" name="schid" id="schid" value="<?php echo $_POST['schid']?>"  />
	<input type="hidden" name="std" id="std" value="<?php echo $_POST['std']?>"  />
	<input type="hidden" name="atdt" id="atdt" value="<?php echo $_POST['atdt']?>"  />
	<input type="hidden" name="atmnth" id="atmnth" value="<?php echo $_POST['atmnth']?>"  />
	<input type="hidden" name="atyr" id="atyr" value="<?php echo $_POST['atyr']?>"  />
      <td class="<?php echo $style?>"><?php echo $i;?> <input type="hidden" name="studid[]" id="studid" value="<?php echo $row['studid']?>"  /></td>
      <td class="<?php echo $style?>"><?php echo $row['nos'];?></td>
      <td class="<?php echo $style?>"><?php echo $row['atstatus'];?><label></label></td>
    </tr>
	<?php
	$i++;
	}
	?>
    </div>
      </label></td>
      
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php');?>
