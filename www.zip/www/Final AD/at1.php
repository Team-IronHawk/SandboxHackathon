<?php include('schsv.php'); ?>
<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<script>
function startCalc()

{
interval = setInterval("calc()",1);
}
function calc()
{
 cls = document.form.std.value;
 
if(cls>=1&&cls<6)
{

document.form.level.value ='PRIMARY';
}
else if(cls>=6&&cls<8)
{
document.form.level.value ='HIGHER PRIMARY';
}
else 
{
document.form.level.value ='HIGH SCHOOL';
}

}

function stopCalc(){
clearInterval(interval);}

</script>
<?php include('dbconnect.php');?>
<?php include('hdr.php');?>
<form name="form" method="post" action="at2.php">
  <table width="400" border="1" align="center">
    <tr><?php 
		$schid=$_SESSION['schid'];
		$sql="select * from school where schid='$schid'";
		$res=mysql_query($sql);
		$row=mysql_fetch_array($res);
		?>
      
        <input name="schid" type="hidden" value="<?php echo $row['schid'];?> " id="schid" />
      <td class="lhead" bgcolor="#663333" width="50%">Select Standarad </td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><select name="std" id="std" style="width:190px" onfocus="startCalc(); "required x-moz-errormessage="Please Select Stanadard">
        <option selected="selected" value="">Select</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
      </select>        &nbsp;</td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Level</td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><label>
        <input name="level" type="text" id="level" onFocus="startCalc();" onBlur="stopCalc();" style="width:189px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Attendance Date </td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"> 
        <select name="atdt" id="atdt" style="width:190px" required x-moz-errormessage="Please Select Date">
		<option selected="selected" value="">Select</option>
		<?php
		$i=1;
do{
		?>
        <option value="<?php echo $i?>"><?php echo $i;?></option>
        <?php
		$i++;
		}
		while($i<32)
		
		?>
      </select>        &nbsp;</td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Attendance Month </td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata">
	  <select name="atmnth" id="atmnth"  style="width:190px" required x-moz-errormessage="Please Select Month">
	  <option selected="selected" value="">Select</option>
          <option value="JANUARY">JANUARY</option>
          <option value="FEBRUARY">FEBRUARY</option>
          <option value="MARCH">MARCH</option>
          <option value="APRIL">APRIL</option>
          <option value="MAY">MAY</option>
          <option value="JUNE">JUNE</option>
          <option value="JULY">JULY</option>
          <option value="AUGUST">AUGUST</option>
          <option value="SEPTEMBER">SEPTEMBER</option>
          <option value="OCTOBER">OCTOBER</option>
          <option value="NOVEMBER">NOVEMBER</option>
          <option value="DECEMBER">DECEMBER</option>
        </select>&nbsp;</td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Attendance Year </td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata">
	  <select name="atyr" id="atyr" style="width:190px"  required x-moz-errormessage="Please Select Year">
       <option selected="selected" value="">Select</option> 
		<?php
		$y=2010;
do{
		?>
		
        <option value="<?php echo $y;?>"><?php echo $y;?></option>
        <?php
		$y++;
		}
		while($y<2051)
		
		?>
      </select>&nbsp;</td>
    </tr>
    <tr align="center">
      <td colspan="2"><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>
