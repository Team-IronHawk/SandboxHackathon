<?php include('schsv.php'); ?>
<?php include('hdr.php');?>
<?php include('dbconnect.php');?>
<script>
function startCalc()

{
interval = setInterval("calc()",1);
}
function calc()
{
 cls = document.form.std.value;
 
if(cls>=1&&cls<6)
{

document.form.level.value ='PRIMARY';
}
else if(cls>=6&&cls<8)
{
document.form.level.value ='HIGHER PRIMARY';
}
else 
{
document.form.level.value ='HIGH SCHOOL';
}

}


function stopCalc(){
clearInterval(interval);}
function isnumber(a,b)
{

   var re=/^\d+$/;
   if(a=="")
   {
   document.getElementById(b).innerHTML="This feild is Required";     
   }
   else if(re.test(a))
   {
document.getElementById(b).innerHTML="";     
   }
   else
   {
   document.getElementById(b).innerHTML="Enter only numbers";
   }
}
</script>
<link rel="stylesheet" type="text/css" href="CalendarControl.css" />
<script language="JavaScript" src="CalendarControl.js" type="text/javascript"></script>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form" method="post" action="savestudent.php">
  <table width="400" border="1" align="center">
    
   
    <tr>
	 <?php 
		$schid=$_SESSION['schid'];
		$sql="select * from school where schid='$schid'";
		$res=mysql_query($sql);
		$row=mysql_fetch_array($res);
		?>
      
        <input name="schid" type="hidden" value="<?php echo $row['schid'];?> " id="schid" />
      <td class="lhead" bgcolor="#663333" width="50%">Name Of Student </td>
      <td bgcolor="#FFFFCC">
	    <script>
        function ns()
        {
          var x=document.getElementById("nos");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*$/))
          {
            window.alert("Please Enter Characters Only");
            document.getElementById("nos").value="";
            document.form.nos.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.age.focus();
          }
         }
      </script><label>
      <input name="nos" type="text" id="nos" required x-moz-errormessage="Please enter student name" onblur="ns()" style="width:189px" />
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Gender</td>
      <td  bgcolor="#FFFFCC"><label>
        <input name="gender" type="radio" value="Male" id="gender"  />
        Male 
        &nbsp; &nbsp; &nbsp;
        <input name="gender" type="radio" value="Female" id="gender" />
        Female
      </label></td>
    </tr>
    <tr >
      <td class="lhead" bgcolor="#663333" width="50%">Age</td>
      <td bgcolor="#FFFFCC">
	   <script>
        function ag()
        {
          var x=document.getElementById("age");
          if(!x.value.match(/^[1]*[1|2|3|4|5|6|7|8|9]+$/))
          {
            window.alert("Please Enter Proper Age");
            document.getElementById("age").value="";
            document.form.age.focus();
           }
         }
      </script>
	  <label>
	  <input name="age" type="text" id="age" maxlength="2" required x-moz-errormessage="Please enter age" onblur="ag()" style="width:189px"/>
	  </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Standard</td>
      <td bgcolor="#FFFFCC"><label>
      <select name="std" id="std" style="width:190px" onfocus="startCalc();" required x-moz-errormessage="Please Select Stanadard">
        <option selected="selected" value="">Select</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Level</td>
      <td bgcolor="#FFFFCC"><label>
      <input name="level" type="text" id="level" onFocus="startCalc();" onBlur="stopCalc();" style="width:189px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Date Of  Birth </td>
      <td bgcolor="#FFFFCC"><label>
      <input name="dob" type="text" id="dob" onfocus="showCalendarControl(this)" style="width:189px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Annual Income </td>
      <td bgcolor="#FFFFCC"><label>
      <input name="annualincome" type="text" id="annualincome" required="1" style="width:189px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Religion</td>
      <td bgcolor="#FFFFCC"><label>
      <input name="caste" type="text" id="caste" required="1" style="width:189px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Category</td>
      <td bgcolor="#FFFFCC"><label>
      <select name="category" id="category" style="width:190px"  required x-moz-errormessage="Please Select Category">
	  <option selected="selected" value="">Select</option>
        <option value="S.C.">S.C.</option>
        <option value="S.T.">S.T.</option>
        <option value="Minorities">Minorities</option>
        <option value="Others">Others</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Physical Disable </td>
      <td bgcolor="#FFFFCC"><label>
        <input name="phydisable" type="radio" value="yes"  />
      Yes 
      &nbsp; &nbsp; &nbsp; &nbsp;<input name="phydisable" type="radio" value="no" checked="checked"/>
      No</label></td>
    </tr>
    <tr bgcolor="#FFFFCC" align="center">
      <td  bgcolor="#FFFFCC" id=""><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset" class="button">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>