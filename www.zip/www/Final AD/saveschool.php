<?php include('dbconnect.php'); ?>
<?php
$schid=$_POST['schid'];
$schname=$_POST['schname'];
$schtype=$_POST['schtype'];
$schauthority=$_POST['schauthority'];
$doe=$_POST['doe'];
$dor=$_POST['dor'];
$schaddress=$_POST['schaddress'];
$place=$_POST['place'];
$taluk=$_POST['taluk'];
$district=$_POST['district'];
$schpno=$_POST['schpno'];
$sql="insert into school values(null,'$schname','$schtype','$schauthority','$doe','$dor','$schaddress','$place','$taluk','$district','$schpno')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New School Details inseted successfully");
document.location="listschool.php";
</script>