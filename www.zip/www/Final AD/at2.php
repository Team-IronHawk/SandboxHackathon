<?php include('hdr.php'); ?>
<?php include('dbconnect.php');?>
<?php
$sql="select * from attendence where schid='".$_POST['schid']."' and std = '".$_POST['std']."' and atdt = '".$_POST['atdt']."' and atmnth = '".$_POST['atmnth']."' and atyr = '".$_POST['atyr']."'";
$res = mysql_query($sql);
					if($row = mysql_fetch_array($res))
					{
					?>
					<script type="text/javascript" language="php">

alert("Attendance Already Given...");
document.location="at1.php";
</script>
<?php
					}
					else
					{

?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="at3.php">
  <p>&nbsp;</p>
  <table width="200" border="1" align="center">
    <tr bgcolor="#663333" class="lhead">
      <td>Sl No </td>
      <td>Student name </td>
      <td>Stattus</td>
    </tr>
	<?php 
	$i=1;
	$sql="select * from student where schid='".$_POST['schid']."' and std='".$_POST['std']."'";
$res=mysql_query($sql);
while($row=mysql_fetch_array($res))
	{
	?>
    <tr class="ldata" bgcolor="FFFFCC">
	<input type="hidden" name="schid" id="schid" value="<?php echo $_POST['schid']?>"  />
	<input type="hidden" name="std" id="std" value="<?php echo $_POST['std']?>"  />
	<input type="hidden" name="level" id="level" value="<?php echo $_POST['level']?>"  />
	<input type="hidden" name="atdt" id="atdt" value="<?php echo $_POST['atdt']?>"  />
	<input type="hidden" name="atmnth" id="atmnth" value="<?php echo $_POST['atmnth']?>"  />
	<input type="hidden" name="atyr" id="atyr" value="<?php echo $_POST['atyr']?>"  />
      <td><?php echo $i;?> <input type="hidden" name="studid[]" id="studid" value="<?php echo $row['studid']?>"  /></td>
      <td><?php echo $row['nos'];?></td>
      <td><label>
        <select name="<?php echo $row['studid']?>"  id="atstatus">
          <option value="P">P</option>
          <option value="A">A</option>
        </select>
      </label></td>
    </tr>
	<?php
	$i++;
	}
	
	?>
    <tr>
      <td colspan="3">
       
          <input type="submit" name="Submit" value="Submit">
          </div>
      </label></td>
      
    </tr>
  </table>
  <p>&nbsp;</p>
  <?php
  }
  ?>
</form>
<?php include('ftr.php'); ?>