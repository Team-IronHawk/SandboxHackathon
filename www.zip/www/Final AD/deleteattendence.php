<?php include('dbconnect.php');?>
<?php
$atid=$_GET['atid'];
$sql="delete from attendence where atid='$atid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("attendence Details Deleted successfully");
document.location="listattendence.php";
</script>