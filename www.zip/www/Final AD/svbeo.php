<?php
session_start();
if(!(isset($_SESSION['aduname'])) || ($_SESSION['aduname'] == ""))
{
	?>
		<script>
			alert('Your session has been expired');
			document.location='index.html';
		</script>
	<?php
}
?>