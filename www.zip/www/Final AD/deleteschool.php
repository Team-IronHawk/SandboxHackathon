<?php include('dbconnect.php');?>
<?php
$schid=$_GET['schid'];
$sql="delete from school where schid='$schid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("Student Details Deleted successfully");
document.location="listschool.php";
</script>