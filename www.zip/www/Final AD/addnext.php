<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<?php include('hdr.php'); ?>
<?php include('dbconnect.php');?>
<?php 

$a=0;
?>
<script>
function startCalc()

{
interval = setInterval("calc()",1);
}
function calc()
{
 one = document.form1.l1pbal.value;
 two = document.form1.l1tc.value;
 con1 = document.form1.l1cons.value;
  document.form1.l1bal.value = (one * 1) + (two * 1) - (con1 * 1);
  
  three = document.form1.l2pbal.value;
 four = document.form1.l2tc.value;
 con2 = document.form1.l2cons.value;
  document.form1.l2bal.value = (three * 1) + (four * 1) - (con2 * 1);
  
  five = document.form1.l3pbal.value;
 six = document.form1.l3tc.value;
 con3 = document.form1.l3cons.value;
  document.form1.l3bal.value = (five * 1) + (six * 1) - (con3 * 1);

  }


function stopCalc(){
clearInterval(interval);}
 </script>

<form name="form1" method="post" action="saveadd.php">

  <table width="400" border="1" align="center">
  
    <tr>
      <td bgcolor="#663333" class="lhead">Level 1 Last Balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
	  <input type="hidden" name="cid" id="cid" value="<?php echo $_POST['cid']?>"  />
	  <input type="hidden" name="schid" id="schid" value="<?php echo $_POST['schid']?>"  />
	  <input type="hidden" name="cdt" id="cdt" value="<?php echo $_POST['cdt']?>"  />
	  <input type="hidden" name="cmt" id="cmt" value="<?php echo $_POST['cmt']?>"  />
	  <input type="hidden" name="cyr" id="cyr" value="<?php echo $_POST['cyr']?>"  />
	  
	 	  
      <input name="l1pbal" type="text" id="l1pbal" onFocus="startCalc();" onBlur="stopCalc();" style="width:183px"/>
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 2 Last Balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l2pbal" type="text" id="l2pbal" required="1" onFocus="startCalc();" onBlur="stopCalc();" style="width:183px"/>
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 3 Last Balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l3pbal" type="text" id="l3pbal" required="1" onFocus="startCalc();" onBlur="stopCalc();" style="width:183px"/>
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Today Credit For 1-5 </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l1tc" type="text" id="l1tc"  onFocus="startCalc();" onBlur="stopCalc();" style="width:183px"/>
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Today Credit For 6-7 </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l2tc" type="text" id="l2tc" required="1" onFocus="startCalc();" onBlur="stopCalc();" style="width:183px"/>
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Today Credit For 7-10 </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l3tc" type="text" id="l3tc" required="1" onFocus="startCalc();" onBlur="stopCalc();" style="width:183px"/>
      </label></td>
    </tr>
	<?php
	
	$sqll1s="select count(*) as cnt from attendence where level='PRIMARY' and atstatus='P'  and atdt='".$_POST['cdt']."' and atmnth='".$_POST['cmt']."' and atyr ='".$_POST['cyr']."' and schid='".$_POST['schid']."'";
	$lv1s=mysql_query($sqll1s);
	$rlv1s=mysql_fetch_array($lv1s);
	$a=$rlv1s['cnt'];
	?>

	
    <tr>
      <td bgcolor="#663333" class="lhead">Level 1 Strength </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l1strength" type="hidden" id="l1strength" value="<?php echo $a;?>" />
        <?php echo $rlv1s['cnt'];?> </label></td>
    </tr>
	<?php
	$b=0;
	$sqll2s="select count(*) as cnta from attendence where level='HIGHER PRIMARY' and atstatus='P' and atdt='".$_POST['cdt']."' and atmnth='".$_POST['cmt']."' and atyr ='".$_POST['cyr']."' and schid='".$_POST['schid']."'";
	$lv2s=mysql_query($sqll2s);
	$rlv2s=mysql_fetch_array($lv2s);
	$b=$rlv2s['cnta'];
	?>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 2 Strength </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
         <input name="l2strength" type="hidden" id="l2strength" value="<?php echo $b;?>" />
        <?php echo $rlv2s['cnta'];?> </label></td>
    </tr>
	
    <tr>
	<?php
	$c=0;
	$sqll3s="select count(*) as cntb from attendence where level='HIGH SCHOOL' and atstatus='P' and atdt='".$_POST['cdt']."' and atmnth='".$_POST['cmt']."' and atyr ='".$_POST['cyr']."' and schid='".$_POST['schid']."'";
	$lv3s=mysql_query($sqll3s);
	$rlv3s=mysql_fetch_array($lv3s);
	$c=$rlv3s['cntb'];
	?>
      <td bgcolor="#663333" class="lhead">Level 3 Strength </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l3strength" type="hidden" id="l3strength" value="<?php echo $c;?>" />
        <?php echo $rlv3s['cntb'];?> </label></td>
    </tr>
	<?php
	$d=0;
	$sqll1c="select * from comsumable where cid='".$_POST['cid']."'";
	$resl1c=mysql_query($sqll1c);
	$rowl1c=mysql_fetch_array($resl1c);
	$l1c=$rowl1c['l1rps'];
	$tota=$a*$l1c;
	$totakg=$tota/1000;
	?>
    
    <tr>
	
      <td bgcolor="#663333" class="lhead">Level 1 Consumed </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l1cons" type="hidden" id="l1cons"  value="<?php echo $tota;?>">
     <?php echo $tota;?></label></td>
    </tr>
	<?php
	
	$sqll2c="select * from comsumable where cid='".$_POST['cid']."'";
	$resl2c=mysql_query($sqll2c);
	$rowl2c=mysql_fetch_array($resl2c);
	$l2c=$rowl2c['l2rps'];
	$totb=$b*$l2c;
	$totakg=$tota/1000;
	?>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 2 Consumed </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l2cons" type="hidden" id="l2cons" value="<?php echo $totb;?>">
     <?php echo $totb;?> </label></td>
    </tr>
	<?php
	
	$sqll3c="select * from comsumable where cid='".$_POST['cid']."'";
	$resl3c=mysql_query($sqll3c);
	$rowl3c=mysql_fetch_array($resl3c);
	$l3c=$rowl3c['l3rps'];
	$totc=$c*$l3c;
	$totakg=$tota/1000;
	?>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 3 Consumed </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l3cons" type="hidden" id="l3cons" value="<?php echo $totc;?>">
      <?php echo $totc;?></label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 1 Balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l1bal" type="text" id="l1bal" required="1" onFocus="startCalc();" onBlur="stopCalc();" style="width:183px">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 2 Balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l2bal" type="text" id="l2bal" required="1" onFocus="startCalc();" onBlur="stopCalc();" style="width:183px">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level 3 Balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l3bal" type="text" id="l3bal" required="1" onFocus="startCalc();" onBlur="stopCalc();" style="width:183px">
      </label></td>
    </tr>
    <tr bgcolor="" align="center">
      <td><label>
        <input type="submit" name="Submit" value="Submit">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset">
      </label></td>
    </tr>
  </table>
</form>
<?php include('ftr.php'); ?>