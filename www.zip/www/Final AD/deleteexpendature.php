<?php include('dbconnect.php');?>
<?php
$exid=$_GET['exid'];
$sql="delete from expenditure where exid='$exid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("expenditure Details Deleted successfully");
document.location="listexpendature.php";
</script>