<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>AKSHARA DASOHA WEB SITE PROJECT</title>
<link rel="stylesheet" href="styles.css" type="text/css" />
<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--
educate, a free CSS web template by ZyPOP (zypopwebtemplates.com/)

Download: http://zypopwebtemplates.com/

License: Creative Commons Attribution
//-->

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/slider.js"></script>
<script type="text/javascript" src="js/superfish.js"></script>

<script type="text/javascript" src="js/custom.js"></script>

<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
</head>
<body>
<div id="container">

    <header>
	
    		
        <nav>
	<div class="width">
    			<ul class="sf-menu dropdown">
        	<li class="selected"><a href="beohome.php">Home</a></li>
			 <li><a class="has_submenu" href="#">School</a>
            	<ul>
                	<li><a href="newschool.php">Add School</a></li>
                    <li><a href="listschool.php">View School</a></li>
					<li><a href="newstaff.php">Add Staff</a></li>
                    <li><a href="liststaff.php">View Staff</a></li>  
					<li><a href="listregistration.php">Login Details</a></li>
                </ul>
            </li>
			 <li><a class="has_submenu" href="#">Consumable</a>
            	<ul>
                	<li><a href="newconsumable.php">Add</a></li>
                    <li><a href="listconsumable.php">View</a></li>   
                </ul>
            </li>
			<li><a class="has_submenu" href="#">Consumable Reports</a>
            	<ul>
                	<li><a href="beoviewconl11.php">Primary</a></li>
                    <li><a href="beoviewconl21.php">Higher Primary</a></li>   
					<li><a href="beoviewconl31.php">High School</a></li>  
                </ul>
            </li>
			<li><a href="beoviewex1.php">Expenditure</a></li>
			<li><a class="has_submenu" href="#">Attendance</a>
            	<ul>
                	<li><a href="beoviewatl11.php">Primary</a></li>  
					<li><a href="beoviewatl21.php">Higher Primary</a></li>
					<li><a href="beoviewatl31.php">High School</a></li>
                </ul>
            </li>
			<li><a href="logout.php">Log Out</a></li>
        </ul>
		
          </div>
	
		<div class="clear"></div>
	
    </nav>

    <h1><a href="/">Akshara Dasoha </a></h1>
	

    

    </header>




    <div id="body" class="width" align="center">
