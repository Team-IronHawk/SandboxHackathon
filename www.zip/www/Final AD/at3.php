<?php include('dbconnect.php'); ?>
<?php
$atid=$_POST['atid'];
$schid=$_POST['schid'];
$studid=$_POST['studid'];
$atdt=$_POST['atdt'];
$atmnth=$_POST['atmnth'];
$atyr=$_POST['atyr'];
$level=$_POST['level'];
$std=$_POST['std'];
$atstatus=$_POST['atstatus'];
if($studid!=null)
{
   foreach($studid as $value)
   {
      $s=$_POST[$value];
	  $sql="select * from attendence where studid='$value' and atdt='$atdt' and atmnth='$atmnth' and atyr='$atyr' and std='$std'";
	  $res=mysql_query($sql);
	  if($row=mysql_fetch_array($res))
	  {
$sql="update attendence set schid='$schid',std='$std',studid='$value',atdt='$atdt',atmnth='$atmnth',atyr='$atyr',atstatus='$s' where studid='$value' and atdt='$atdt' and atmnth='$atmnth' and atyr='$atyr' and schid='$schid' and std='$std'";
	  
	  }
	  else
	  {
	  $sql="insert into attendence values(null,'$schid','$value','$atdt','$atmnth','$atyr','$level','$std','$s')";
	  }
	// echo $sql;
      mysql_query($sql);
      
   }
}
?>
<script type="text/javascript" language="php">
alert("New attendence inserted successfully");
document.location="schhome.php";
</script>