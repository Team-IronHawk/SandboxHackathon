<?php include('dbconnect.php'); ?>
<?php
$dcid=$_POST['dcid'];
$cid=$_POST['cid'];
$schid=$_POST['schid'];
$cdt=$_POST['cdt'];
$cmt=$_POST['cmt'];
$cyr=$_POST['cyr'];
$l1pbal=$_POST['l1pbal'];
$l2pbal=$_POST['l2pbal'];
$l3pbal=$_POST['l3pbal'];
$l1tc=$_POST['l1tc'];
$l2tc=$_POST['l2tc'];
$l3tc=$_POST['l3tc'];
$l1strength=$_POST['l1strength'];
$l2strength=$_POST['l2strength'];
$l3strength=$_POST['l3strength'];
$l1cons=$_POST['l1cons'];
$l2cons=$_POST['l2cons'];
$l3cons=$_POST['l3cons'];
$l1bal=$_POST['l1bal'];
$l2bal=$_POST['l2bal'];
$l3bal=$_POST['l3bal'];s
$sql="update cadd set cid='$cid',schid='$schid',cdt='$cdt',cmt='$cmt',cyr='$cyr',l1pbal='$l1pbal',l2pbal='$l2pbal',l3pbal='$l3pbal',l1tc='$l1tc',l2tc='$l2tc',l3tc='$l3tc',l1strength='$l1strength',l2strength='$l2strength',l3strength='$l3strength',l1cons='$l1cons',l2cons='$l2cons',l3cons='$l3cons',l1bal='$l1bal',l2bal='$l2bal',l3bal='$l3bal' where dcid='$dcid' ";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New consumable details inseted successfully");
document.location="listadd.php";
</script>