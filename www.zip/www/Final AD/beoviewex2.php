<?php include('hdr1.php'); ?>
<?php include('dbconnect.php');?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<?php
$sql="select * from expenditure where schid='".$_POST['schid']."' and exmnth='".$_POST['exmnth']."' and exyr='".$_POST['exyr']."'";
$res=mysql_query($sql);
$sqlamt="select sum(amtpaid) as amt from expenditure where  schid='".$_POST['schid']."' and exmnth='".$_POST['exmnth']."' and exyr='".$_POST['exyr']."'";
$schid=$_POST['schid'];
$exmnth=$_POST['exmnth'];
$exyr=$_POST['exyr'];
$rt=mysql_query($sqlamt);
$tot=mysql_fetch_array($rt);

?>
<p>&nbsp;</p>
<form name="form1" method="post" action="printexp.php">
<table width="200" border="1" align="center">

  <tr class="lhead" bgcolor="#663333" width="50%">
    
    <td>Expendature Name</td>
 <input type="hidden" name="schid" id="schid" value="<?php echo $schid; ?>"  />
 <input type="hidden" name="exmnth" id="exmnth" value="<?php echo $exmnth;?>"  />
 <input type="hidden" name="exyr" id="exyr" value="<?php echo $exyr;?>"  />
    <td>Discription</td>
    <td>Date </td>
    <td>Month </td>
    <td>Year </td>
    <td>Amount To Be Paid</td>
    <td>Amount In Rupees </td>
    </tr>
  <?php
	while($row=mysql_fetch_array($res))
	{$style="dr";
	$style1="#FFFFCC";
	if($m % 2 != 0){
	$style="sr";
	$style1="#FFFFCC";
	}
	$m++;
	?>
  <tr bgcolor="<?php echo $style1?>"  onmouseover="MouseOver(this);" onmouseout="MouseOut(this);" class="lrow">
   
    <td class="<?php echo $style?>"><?php echo $row['exname']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['discription']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['exdt']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['exmnth']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['exyr']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['amtpaid']; ?>&nbsp;</td>
    <td class="<?php echo $style?>"><?php echo $row['amtrs']; ?>&nbsp;</td>
    </tr>
	<?php
	}
	?>
  <tr bgcolor="#FFFFCC"  onmouseover="MouseOver(this);" onmouseout="MouseOut(this);">
    <td  class="<?php echo $style?>" colspan="5" align="right">Total Amount: </td>
    
    <td class="<?php echo $style?>" ><?php echo $tot['amt'];?></td>
    <td>&nbsp;</td>
  </tr>
  	
</table>
 
<p align="center"><a href="printexp.php">
  <label>
  <input type="submit" name="Submit" value="Print" />
  </label>
</a></p>
</form>
<?php include('ftr.php'); ?>