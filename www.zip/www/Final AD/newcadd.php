
<?php include('hdr.php'); ?>
<?php include('dbconnect.php');?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="addnext.php">

  <table width="400" border="1" align="center">
  
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Consumable Name </td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><label>
      <select name="cid" id="cid" required x-moz-errormessage="Please Select Consumable" style="width:190px">
        <?php
	  $sql="select * from comsumable";
	  $res=mysql_query($sql);
	  ?>
	  <option selected="selected" value="">Select</option>
        <?php 
	  while($row=mysql_fetch_array($res))
	  {
	  ?>
	  <option value="<?php echo $row['cid']; ?>"><?php echo $row['cname']; ?></option>
        <?php } ?>
      </select>
      </label></td>
    </tr>
	
    <tr>
	<?php 
		$schid=$_SESSION['schid'];
		$sql="select * from school where schid='$schid'";
		$res=mysql_query($sql);
		$row=mysql_fetch_array($res);
		?>
      
        <input name="schid" type="hidden" value="<?php echo $row['schid'];?> " id="schid" />
      <td class="lhead" bgcolor="#663333" width="50%">Date</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <select name="cdt" id="cdt" required x-moz-errormessage="Please Select Date" style="width:190px">
        <option selected="selected" value="">Select</option>
		  <?php
		$i=1;
do{
		?>
		
          <option value="<?php echo $i?>"><?php echo $i;?></option>
          <?php
		$i++;
		}
		while($i<32)
		
		?>
        </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Month</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <select name="cmt" id="cmt" required x-moz-errormessage="Please Select Month" style="width:190px">
          <option selected="selected" value="">Select</option>
		  <option value="JANUARY">JANUARY</option>
          <option value="FEBRUARY">FEBRUARY</option>
          <option value="MARCH">MARCH</option>
          <option value="APRIL">APRIL</option>
          <option value="MAY">MAY</option>
          <option value="JUNE">JUNE</option>
          <option value="JULY">JULY</option>
          <option value="AUGUST">AUGUST</option>
          <option value="SEPTEMBER">SEPTEMBER</option>
          <option value="OCTOBER">OCTOBER</option>
          <option value="NOVEMBER">NOVEMBER</option>
          <option value="DECEMBER">DECEMBER</option>
        </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Year</td>
      <td  bgcolor="#FFFFCC" class="ldata"><select name="cyr" id="cyr" required x-moz-errormessage="Please Select Year" style="width:190px">
       <option selected="selected" value="">Select</option><br />
	   <?php
		$y=2010;
do{
		?>
		
          <option value="<?php echo $y;?>"><?php echo $y;?></option>
          <?php
		$y++;
		}
		while($y<2051)
		
		?>
      </select></td>
    </tr>
    
    <tr align="center">
      <td ><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset" class="button">
      </label></td>
    </tr>
  </table>
</form>
<?php include('ftr.php'); ?>