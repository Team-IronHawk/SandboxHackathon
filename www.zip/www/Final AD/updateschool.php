<?php include('dbconnect.php'); ?>
<?php
$schid=$_POST['schid'];
$schname=$_POST['schname'];
$schtype=$_POST['schtype'];
$schauthority=$_POST['schauthority'];
$doe=$_POST['doe'];
$dor=$_POST['dor'];
$schaddress=$_POST['schaddress'];
$place=$_POST['place'];
$taluk=$_POST['taluk'];
$district=$_POST['district'];
$schpno=$_POST['schpno'];
$sql="update school set schname='$schname',schtype='$schtype',schauthority='$schauthority',doe='$doe',dor='$dor',schaddress='$schaddress',place='$place',taluk='$taluk',district='$district',schpno='$schpno' where schid='$schid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New School Details inseted successfully");
document.location="listschool.php";
</script>