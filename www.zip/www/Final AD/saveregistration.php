
<?php include('dbconnect.php'); ?>
<?php
$regid=$_POST['regid'];
$schid=$_POST['schid'];
$scuname=$_POST['scuname'];
$scpwd=$_POST['scpwd'];
$sql="insert into registration values(null,'$schid','$scuname','$scpwd')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New Registration Details inseted successfully");
document.location="listregistration.php";
</script>