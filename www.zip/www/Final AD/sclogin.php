<?php include('dbconnect.php');?>
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>AKSHARA DASOHA WEB SITE PROJECT</title>
<link rel="stylesheet" href="styles.css" type="text/css" />
<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--
educate, a free CSS web template by ZyPOP (zypopwebtemplates.com/)

Download: http://zypopwebtemplates.com/

License: Creative Commons Attribution
//-->

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/slider.js"></script>
<script type="text/javascript" src="js/superfish.js"></script>

<script type="text/javascript" src="js/custom.js"></script>

<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
</head>
<body>
<div id="container">

    <header>
	
    		
        <nav>
	<div class="width">
    			<ul class="sf-menu dropdown">
        	<li class="selected"><a href="index.html">Home</a></li>
			</div>
	
		<div class="clear"></div>
	
    </nav>

    <h1><a href="/">Akshara Dasoha </a></h1>
	

    

    </header>




    <div id="body" class="width" align="center">
	  <form id="form1" name="form1" method="post" action="scchklogin.php">
	    <table width="200" border="1">
          <tr>
            <td bgcolor="#663333" class="lhead">SELECT SCHOOL </td>
            <td bgcolor="#FFFFCC" class="ldata"><select name="schid" id="schid">
	   <?php 
	  $sql="select * from school";
	  $res=mysql_query($sql);
	  while($row=mysql_fetch_array($res))
	  {
	  ?>
	  <option selected="selected" value="<?php echo $row['schid'];?>"><?php echo $row['schname'];?></option>
	  <?php
	  }
	  ?>
      </select></td>
          </tr>
          <tr>
            <td bgcolor="#663333" class="lhead">USERNAME</td>
            <td bgcolor="#FFFFCC" class="ldata"><label>
              <input name="scuname" type="text" id="scuname" />
            </label></td>
          </tr>
          <tr>
            <td bgcolor="#663333" class="lhead">PASSWORD</td>
            <td bgcolor="#FFFFCC" class="ldata"><label>
              <input name="scpwd" type="password" id="scpwd" />
            </label></td>
          </tr>
        </table>
        <p>
          <label>
          <input type="submit" name="Submit" value="Login" />
          </label>
        </p>
	  </form>
</div><br /><br /><br /><br /><br /><br /><br /><br /><br />
    <footer>

         <p>Akshar Dasoha Website by STSKK POLYTECNIC CS STUDENTS GADAG-582101</p>
      
    </footer>
</div>
</body>
</html><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
