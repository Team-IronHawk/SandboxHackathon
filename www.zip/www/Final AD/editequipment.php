<?php include('schsv.php'); ?>
<?php include('hdr.php');?>
<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="CalendarControl.css" />
<script language="JavaScript" src="CalendarControl.js" type="text/javascript"></script>
<?php include('dbconnect.php');?>
<?php
$eid=$_GET['eid'];
$sql="select * from equipment where eid='$eid'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?>
<form name="form1" method="post" action="updateequipment.php">
  <table width="400" border="1" align="center">
    <tr>
	<?php 
		$schid=$_SESSION['schid'];
		$sql1="select * from school where schid='$schid'";
		$res1=mysql_query($sql1);
		$row1=mysql_fetch_array($res1);
		?>
      
        <input name="schid" type="hidden" value="<?php echo $row1['schid'];?> " id="schid" />
      <td class="lhead" bgcolor="#663333" width="50%">Equipment Name </td>
      <td bgcolor="#FFFFCC" class="ldata">
	      <script>
        function enam()
        {
          var x=document.getElementById("ename");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*$/))
          {
            window.alert("Please Enter Characters Only");
            document.getElementById("ename").value="";
            document.form.ename.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.ename.focus();
          }
         }
      </script>
	  <label>
	  <input name="ename" type="text" id="ename" value="<?php echo $row['ename'];?>" required x-moz-errormessage="Please enter Expendature name" onblur="enam()" style="width:183px" />
	  </label></td>
    </tr>
	 <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Equipment Type </td>
      <td bgcolor="#FFFFCC" class="ldata"><label><select name="etype" id="etype"  style="width:190px" required x-moz-errormessage="Please Select Equipment">
	  <option selected="selected" value="">Select</option>
        <option value="PLASTIC">PLASTIC</option>
        <option value="STEEL">STEEL</option>
      </select></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Capacity</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="capacity" type="text" id="capacity" value="<?php echo $row['capacity'];?>" required="1" style="width:183px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Date Of Purchase </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="dop" type="text" id="dop" onfocus="showCalendarControl(this)" value="<?php echo $row['dop'];?>" required="1" style="width:183px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Condition</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="cndition" type="text" id="cndition" value="<?php echo $row['cndition'];?>" required="1" style="width:183px">
      </label></td>
    </tr>
    <tr  bgcolor="#FFFFCC" class="ldata" align="center">
      <td><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
      <td><label>
        <input type="reset" name="reset" value="Reset" class="button">
      </label></td>
    </tr>
  </table>
</form>
<?php include('ftr.php');?>
