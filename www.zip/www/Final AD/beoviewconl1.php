<?php include('hdr1.php'); ?>
<?php include('dbconnect.php');?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="">
  <p>&nbsp;</p>
  <table width="200" border="1" align="center">
    <tr class="lhead" bgcolor="#663333" width="50%">
      <td>Date </td>
      <td>Strength</td>
      <td>Last Balance </td>
      <td>Today credit </td>
      <td>Total</td>
      <td>Today Consumed </td>
      <td>End Balance </td>
    </tr>
    <tr  bgcolor="<?php echo $style1?>"  onmouseover="MouseOver(this);" onmouseout="MouseOut(this);" class="lrow">
      <td class="<?php echo $style?>">&nbsp;</td>
      <td class="<?php echo $style?>">&nbsp;</td>
      <td class="<?php echo $style?>">&nbsp;</td>
      <td class="<?php echo $style?>">&nbsp;</td>
      <td class="<?php echo $style?>">&nbsp;</td>
      <td class="<?php echo $style?>">&nbsp;</td>
      <td class="<?php echo $style?>">&nbsp;</td>
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>
