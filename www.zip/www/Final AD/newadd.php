<?php include('schsv.php'); ?>
<?php include('hdr.php'); ?>
<?php include('dbconnect.php');?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="saveadd.php">
  <table width="200" border="1" align="center">
    <tr>
      <td bgcolor="#663333" class="lhead">Consumable ID </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <select name="cid" id="cid">
	   <?php 
	  $sql="select * from comsumable";
	  $res=mysql_query($sql);
	  while($row=mysql_fetch_array($res))
	  {
	  ?>
	  <option selected="selected" value="<?php echo $row['cid'];?>"><?php echo $row['cname'];?></option>
	  <?php
	  }
	  ?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">School ID </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <select name="schid" id="schid">
	   <?php 
	  $sql="select * from school";
	  $res=mysql_query($sql);
	  while($row=mysql_fetch_array($res))
	  {
	  ?>
	  <option selected="selected" value="<?php echo $row['schid'];?>"><?php echo $row['schname'];?></option>
	  <?php
	  }
	  ?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Attendence ID </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <select value="attid" id="attid">
	   <?php 
	  $sql="select * from attendence";
	  $res=mysql_query($sql);
	  while($row=mysql_fetch_array($res))
	  {
	  ?>
	  <option selected="selected" value="<?php echo $row['atid'];?>"><?php echo $row['atid'];?></option>
	  <?php
	  }
	  ?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level1 strength </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l1strength" type="text" id="l1strength">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level2 strength </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l2strength" type="text" id="l2strength">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level3 strength </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l3strength" type="text" id="l3strength">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level1 consumed </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l1cons" type="text" id="l1cons">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level2 consumed </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l2cons" type="text" id="l2cons">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level3 consumed </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l3cons" type="text" id="l3cons">
      </label></td>
    </tr>
    <tr>
      <td  bgcolor="#663333" class="lhead">Level1 balance</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="l1bal" type="text" id="l1bal">
      </label></td>
    </tr>
    <tr>
      <td  bgcolor="#663333" class="lhead">Level2 balance</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l2bal" type="text" id="l2bal">
      </label></td>
    </tr>
    <tr>
      <td bgcolor="#663333" class="lhead">Level3 balance </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <input name="l3bal" type="text" id="l3bal">
      </label></td>
    </tr>
    <tr>
      <td><label>
        <input type="submit" name="Submit" value="Submit">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset">
      </label></td>
    </tr>
  </table>
</form>
<?php include('ftr.php'); ?>
