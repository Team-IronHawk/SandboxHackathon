<?php include('schsv.php'); ?>
<?php include('hdr.php'); ?>
<?php include('dbconnect.php'); ?>
<link rel="stylesheet" href="ourstyle.css" type="text/css" />
<script>
function a()
{
	var schid=document.getElementById("schid").value;
	var std=document.getElementById("std").value;
	
	
	 if(std=="")
	{
	   document.getElementById("result").innerHTML="select any standard";
	}
	else
	{
	   document.getElementById("result").innerHTML="";
	   document.location="liststudent.php?schid="+schid+"&std="+std;
	}
}
</script>
 <?php
 $schid="";
 $std="";
 if(isset($_REQUEST["schid"]))
   $schid=$_REQUEST["schid"];
   if(isset($_REQUEST["std"]))
   $std=$_REQUEST["std"]; 
 ?>
 <link href="styles.css" rel="stylesheet" type="text/css" />
 

<form name="form1" method="post" action="">
  <table width="50%" border="1" align="center">
    
    <tr class="lhead" bgcolor="#663333"> <?php 
		$schid=$_SESSION['schid'];
		$sql="select * from school where schid='$schid'";
		$res=mysql_query($sql);
		$row=mysql_fetch_array($res);
		?>
      
        <input name="schid" type="hidden" value="<?php echo $row['schid'];?> " id="schid" />
      <td width="50%">Select Standard </td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata">
      <select name="std" id="std" onChange="a();" style="width:200px;">
  <option value="">Select</option>
  <?php
					$i=1;
					while($i<11)
					{					
				    ?>
  <option value="<?php echo $i; ?>" <?php if($i==$std) { echo "selected";} ?>><?php echo $i; ?></option>
  <?php
					  $i++;
					}
					?>
</select>
      &nbsp;</td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <?php
$sql="select  stud.*,s.* from student stud,school s where stud.schid=s.schid and stud.schid='$schid' and stud.std='$std'";
$res=mysql_query($sql);
?>
  <div align="center" id="result" class="lnot">Select School and Standard</div>
  <table width="800" border="1" align="center">
    <tr class="lhead" bgcolor="#663333">
	  <td>School Name </td>
      <td>Name Of Student </td>
      <td>Gender</td>
      <td>Standard</td>
      <td>Level</td>
      <td>View Details </td>
      <td>Update</td>
      <td>Delete</td>
    </tr>
	<?php
	while($row=mysql_fetch_array($res))
	{
	$style="dr";
	$style1="#FFFFCC";
	if($m % 2 != 0){
	$style="sr";
	$style1="#FFFFCC";
	}
	$m++;
	?>
    <tr bgcolor="<?php echo $style1?>"  onmouseover="MouseOver(this);" onmouseout="MouseOut(this);" class="ldata">
      <td class="<?php echo $style?>"><?php echo $row['schname']; ?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $row['nos']; ?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $row['gender']; ?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $row['std']; ?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $row['level']; ?>&nbsp;</td>
      <td class="<?php echo $style?>"><a href="viewstud.php?studid=<?php echo $row['studid'];?>">Details</a></td>
      <td class="<?php echo $style?>" align="center"><a href="editstudent.php?studid=<?php echo $row['studid']; ?>"><img src="images/b_edit.png" /></a></td>
      <td class="<?php echo $style?>"  align="center"><a href="deletestudent.php?studid=<?php echo $row['studid'];?>"><img src="images/b_drop.png" /></a></td>
    </tr>
	<?php 
	}
	?>
  </table>
  <p align="center"><a href="newstudent.php"></a> </p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>