<?php include('dbconnect.php');?>
<?php
$dcid=$_GET['dcid'];
$sql="delete from cadd where dcid='$dcid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("cadd Details Deleted successfully");
document.location="listadd.php";
</script>