<?php include('schsv.php'); ?>
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>AKSHARA DASOHA WEB SITE PROJECT</title>
<link rel="stylesheet" href="styles.css" type="text/css" />
<link rel="stylesheet" href="styles.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="CalendarControl.css" />
<script language="JavaScript" src="CalendarControl.js" type="text/javascript"></script>

<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--
educate, a free CSS web template by ZyPOP (zypopwebtemplates.com/)

Download: http://zypopwebtemplates.com/

License: Creative Commons Attribution
//-->

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/slider.js"></script>
<script type="text/javascript" src="js/superfish.js"></script>

<script type="text/javascript" src="js/custom.js"></script>

<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
</head>
<body>
<div id="container">

    <header>
	
    		
        <nav>
	<div class="width">
    			<ul class="sf-menu dropdown">
    		<li class="selected"><a href="schhome.php">Home</a></li>
			 <li><a class="has_submenu" href="#">Student</a>
            	<ul>
                	<li><a href="newstudent.php">Add</a></li>
                    <li><a href="liststudent.php">View</a></li>   
					
                </ul>
            </li>
			<li><a class="has_submenu" href="#">Attendance</a>
            	<ul>
                	<li><a href="at1.php">Add</a></li>  
					<li><a href="viewat1.php">View</a></li>
                </ul>
            </li>
			<li><a class="has_submenu" href="#">Expenditure</a>
            	<ul>
                	<li><a href="newexpendature.php">Add</a></li>
                    <li><a href="listexpendature.php">View</a></li>   
                </ul>
			<li><a class="has_submenu" href="#">Equipment</a>
            	<ul>
                	<li><a href="newequipment.php">Add</a></li>
                    <li><a href="listequipment.php">View</a></li>   
                </ul>
			<li><a class="has_submenu" href="#">Consumable add</a>
            	<ul>
                	<li><a href="newcadd.php">Add</a></li>
                </ul>
            </li>
			<li><a href="logout.php">Log Out</a></li>
        </ul>
		
          </div>
	
		<div class="clear"></div>
	
    </nav>

    <h1><a href="/">Akshara Dasoha </a></h1>
	

    

    </header>




    <div id="body" class="width" align="center">
