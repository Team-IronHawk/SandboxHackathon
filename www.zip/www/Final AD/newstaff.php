<?php include('hdr1.php');?>
<?php include('dbconnect.php');?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="CalendarControl.css" />
<script language="JavaScript" src="CalendarControl.js" type="text/javascript"></script>


<?php include('dbconnect.php');?> 
<form name="form1" method="post" action="savestaff.php">
  <table width="400" border="1" align="center">
    
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">School Id </td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
      <select name="schid" id="schid" style="width:190px">
	    <?php 
		$sql="select * from school";
		$res=mysql_query($sql);
		while($row=mysql_fetch_array($res))
		{
		?>
          <option value="<?php echo $row['schid'];?>"> <?php echo $row['schname']; ?> </option>
        <?php
		}
		?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333">Name</td>
      <td class="ldata" bgcolor="#FFFFCC">
	  <script>
        function n()
        {
          var x=document.getElementById("name");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*$/))
          {
            window.alert("Please Enter Characters Only");
            document.getElementById("name").value="";
            document.form.name.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.name.focus();
          }
         }
      </script><label>
        <input name="name" type="text" id="name" required x-moz-errormessage="Please enter Staff name" onblur="n()" style="width:178px" />
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333">Staff type </td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
      <select name="stafftype" id="stafftype" style="width:190px">
        <option value="Teaching">Teaching</option>
        <option value="Non-teaching">Non-teaching</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333">Designation</td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
      <select name="designation" id="designation" style="width:190px">
        <option value="Principal">Principal</option>
        <option value="H.O.D">H.O.D</option>
        <option value="Lecture">Lecture</option>
        <option value="Clerk">Clerk</option>
        <option value="Librarian">Librarian</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333">Date of joining </td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
        <input name="doj" type="text" id="doj" onfocus="showCalendarControl(this)" required="1" style="width:178px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333">Experience</td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
        <input name="experience" type="text" id="experience" required="1" style="width:178px" />
        </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333">Phone number </td>
      <td class="ldata" bgcolor="#FFFFCC">
	  	  <script>
        function p()
        {
          var x=document.getElementById("phno");
          if(!x.value.match(/^[0-9]{10}$/))
          {
            window.alert("Please Enter Numbers Only");
            document.getElementById("phno").value="";
            document.form.phno.focus();
           }
         }
      </script>
	  <label>
      <input name="phno" type="text" id="phno" required x-moz-errormessage="Please enter Phone Number" onblur="p()" style="width:178px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333">Address</td>
      <td class="ldata" bgcolor="#FFFFCC"><label>
        <textarea name="addr" id="addr" required="1" style="width:178px"></textarea>
      </label></td>
    </tr>
    <tr>
      <td><label>
        <input type="submit" name="Submit" value="Submit">
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php');?>
