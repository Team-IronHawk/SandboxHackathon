<?php session_start(); ?>
<?php include('dbconnect.php');?>
<?php
$schid=$_POST['schid'];
$scuname=$_POST['scuname'];
$scpwd=$_POST['scpwd'];
$sql="select  * from registration where schid='$schid' and scuname='$scuname' and scpwd='$scpwd'";
$result=mysql_query($sql);
if(mysql_num_rows($result)>0)
{
$row=mysql_fetch_array($result);
$_SESSION['schid']=$schid;
$_SESSION['scuname']=$scuname;
$_SESSION['scpwd']=$scpwd;
header("location: schhome.php"); 
} 
else
{
?>
<script>
alert("Invalid login details... Try Again!!");
history.back();
</script>
<?php
}
?>