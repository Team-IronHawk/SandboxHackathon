<?php include('dbconnect.php'); ?>
<?php
$staffid=$_POST['staffid'];
$schid=$_POST['schid'];
$name=$_POST['name'];
$stafftype=$_POST['stafftype'];
$designation=$_POST['designation'];
$doj=$_POST['doj'];
$experience=$_POST['experience'];
$phno=$_POST['phno'];
$addr=$_POST['addr'];
$sql="insert into staff values(null,'$schid','$name','$stafftype','$designation','$doj','$experience','$phno','$addr')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New Staff Details inseted successfully");
document.location="liststaff.php";
</script>