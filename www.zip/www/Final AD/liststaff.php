<?php include('hdr1.php');?>
<?php include('dbconnect.php'); ?>
<?php
$sql="select sf.*,sc.* from staff sf,school sc where sf.schid=sc.schid";
$res=mysql_query($sql);
?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="">
<p>&nbsp;</p>
  <table width="200" border="1" align="center">
    <tr bgcolor="#663333" class="lhead">
      <td>School name</td>
      <td>Name</td>
      <td>Staff type </td>
      <td>Designation</td>
      <td>Date of Joining </td>
      <td>Experienece</td>
      <td>Phone number </td>
      <td>Address</td>
      <td>Update</td>
      <td>Delete</td>
    </tr>
	<?php
	while($row=mysql_fetch_array($res))
	{
	?>
    <tr class="ldata">
      <td><?php echo $row['schname']; ?>&nbsp;</td>
      <td><?php echo $row['name']; ?>&nbsp;</td>
      <td><?php echo $row['stafftype']; ?>&nbsp;</td>
      <td><?php echo $row['designation']; ?>&nbsp;</td>
      <td><?php echo $row['doj']; ?>&nbsp;</td>
      <td><?php echo $row['experience']; ?>&nbsp;</td>
      <td><?php echo $row['phno']; ?>&nbsp;</td>
      <td><?php echo $row['addr']; ?>&nbsp;</td>
      <td align="center"><a href="editstaff.php?staffid=<?php echo $row['staffid'];?>"><img src="images/b_edit.png" /></a></td>
      <td align="center"><a href="deletestaff.php?staffid=<?php echo $row['staffid'];?>"><img src="images/b_drop.png" /></a></td>
    </tr>
	<?php
	}
	?>
  </table>
   <p align="center">&nbsp;</p>
   <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php');?>
