<?php include('svbeo.php');?>
<?php include('hdr1.php'); ?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="CalendarControl.css" />
<script language="JavaScript" src="CalendarControl.js" type="text/javascript"></script>

<form name="form" id="form" enctype="multipart/form-data" method="post" action="saveschool.php">
  <table width="400" border="1" align="center">
    
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Enter School Name</td>
	  <td bgcolor="#FFFFCC" class="ldata">
	  <script>
        function scn()
        {
          var x=document.getElementById("schname");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*[ 0-9]*$/))
          {
            window.alert("Please Enter Characters Only");
            document.getElementById("schname").value="";
            document.form.schname.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.schaddress.focus();
          }
         }
      </script>
	  <input name="schname" type="text" id="schname" placeholder="School Name" required x-moz-errormessage="Please enter school name" onblur="scn()"  style="width:183px"/></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Select Type </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <select name="schtype" id="schtype" style="width:190px" required x-moz-errormessage="Please Select Type">
	  <option selected="selected" value="">Select</option>
        <option value="PRIMARY">PRIMARY</option>
        <option value="HIGHER PRIMARY"> HIGHER PRIMARY</option>
        <option value="HIGH SCHOOL">HIGH SCHOOL</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Select Government/Aided</td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
      <select name="schauthority" id="schauthority" style="width:190px" required x-moz-errormessage="Please Select Type">
	  <option selected="selected" value="">Select</option>
        <option value="PRIVATE">PRIVATE</option>
        <option value="GOVERNMENT">GOVERNMENT</option>
        <option value="GOVT. AIDED">GOVT. AIDED</option>
      </select>
      </label></td>
    </tr>
    <tr>
      <td  class="lhead" bgcolor="#663333" width="50%">Enter Date of Establishment </td>
      <td  bgcolor="#FFFFCC" class="ldata">
        <label>
        <input name="doe" type="text" id="doe" onfocus="showCalendarControl(this)" style="width:183px"/>
      </label>     </td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Enter Date of Registeration </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="dor" type="text" id="dor" onfocus="showCalendarControl(this)"  style="width:183px"/>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Enter Address </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <textarea name="schaddress" id="schaddress" required="1"  style="width:183px"></textarea>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Enter Place </td>
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input name="place" type="text" id="place" required="1"  style="width:183px">
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Enter Taluk </td>
      <td bgcolor="#FFFFCC" class="ldata"><input name="taluk" type="text" id="taluk" required="1"  style="width:183px"></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Select District </td>
      <td bgcolor="#FFFFCC" class="ldata"><input name="district" type="text" id="district" required="1" style="width:183px"></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Enter Phone Number </td>
      <td bgcolor="#FFFFCC" class="ldata">
	    <script>
        function pn()
        {
          var x=document.getElementById("schpno");
          if(!x.value.match(/^[0-9]{5}\-[0-9]{6}$/))
          {
            window.alert("Please Enter Numbers Only");
            document.getElementById("schpno").value="";
            document.form.schpno.focus();
           }
         }
      </script>
	  <input name="schpno" type="text" id="schpno" required x-moz-errormessage="Please enter Phone Number" onblur="pn()"  style="width:183px"></td>
    </tr>
    <tr align="center" bgcolor="#FFFFCC" class="ldata">
      <td><label>
        <input type="submit" name="Submit" value="Submit" class="button" >
      </label></td>
      <td><label>
        <input type="reset" name="Submit2" value="Reset"class="button">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>
