<?php include('schsv.php'); ?>
<?php include('hdr.php');?>
<?php include('dbconnect.php'); ?>
<?php
$sql="select * from expenditure";
$sql="select ex.*,sc.* from expenditure ex,school sc where ex.schid=sc.schid";
$res=mysql_query($sql);
?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />

<p>&nbsp;</p>
<form name="form1" method="post" action="">
<table width="200" border="1" align="center">
  <tr bgcolor="#663333" class="lhead">
    <td>School name </td>
    <td>Expendature name </td>
    <td>Discription</td>
    <td>Expendature date </td>
    <td>Expendature month </td>
    <td>Expendature year </td>
    <td>Amount to be paid</td>
    <td>Amount in Rs </td>
    <td>Update</td>
    <td>Delete</td>
  </tr>
  <?php
	while($row=mysql_fetch_array($res))
	{
	?>
  <tr class="ldata">
    <td><?php echo $row['schname']; ?>&nbsp;</td>
    <td><?php echo $row['exname']; ?>&nbsp;</td>
    <td><?php echo $row['discription']; ?>&nbsp;</td>
    <td><?php echo $row['exdt']; ?>&nbsp;</td>
    <td><?php echo $row['exmnth']; ?>&nbsp;</td>
    <td><?php echo $row['exyr']; ?>&nbsp;</td>
    <td><?php echo $row['amtpaid']; ?>&nbsp;</td>
    <td><?php echo $row['amtrs']; ?>&nbsp;</td>
    <td align="center"><a href="editexpendature.php?exid=<?php echo $row['exid'];?>"><img src="images/b_edit.png" /></a></td>
    <td align="center"><a href="deleteexpendature.php?exid=<?php echo $row['exid'];?>"><img src="images/b_drop.png" /></a></td>
  </tr>
  	<?php
	}
	?>
</table>
 <p align="center"> <a href="newexpendature.php"></a> </p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php');?>

