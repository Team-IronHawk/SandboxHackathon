
<?php include('hdr.php'); ?>
<link rel="stylesheet" type="text/css" href="CalendarControl.css" />
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="CalendarControl.js" type="text/javascript"></script>
<?php include('dbconnect.php'); ?>

<?php
$studid=$_GET['studid']; 
$sql="select stud.*,s.* from student stud,school s where stud.schid=s.schid and stud.studid='$studid'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="savestudent.php">
  <table width="400" border="1" align="center">
    
    <tr>
      <td bgcolor="#663333" class="lhead" width="50%">School Name </td>
      <td bgcolor="#FFFFCC" class="ldata"><label><?php echo $row['schname'];?></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Name Of Student </td>
      <td bgcolor="#FFFFCC" class="ldata">
	    
     <label><?php echo $row['nos'];?></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Gender</td>
      <td bgcolor="#FFFFCC" class="ldata"><label><?php echo $row['gender'];?></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Age</td>
      <td bgcolor="#FFFFCC" class="ldata">
	  
	  <label><?php echo $row['age'];?></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Standard</td>
      <td bgcolor="#FFFFCC" class="ldata"><label><?php echo $row['std'];?></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Level</td>
      <td bgcolor="#FFFFCC" class="ldata"><label><?php echo $row['level'];?></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Date Of Birth </td>
      <td bgcolor="#FFFFCC" class="ldata"><label><?php echo $row['dob'];?></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Annual Income </td>
      <td bgcolor="#FFFFCC" class="ldata"><label><?php echo $row['annualincome'];?></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Caste</td>
      <td bgcolor="#FFFFCC" class="ldata"><label><?php echo $row['caste'];?></label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Category</td>
      <td bgcolor="#FFFFCC" class="ldata"><label><?php echo $row['category'];?></label></td>
    </tr>
    <tr>
      <td height="30" class="lhead" bgcolor="#663333" width="50%">Physical Disable </td>
      <td bgcolor="#FFFFCC" class="ldata"><label><?php echo $row['phydisable'];?></label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('footer.php'); ?>