<?php include('hdr.php'); ?>
<?php include('dbconnect.php'); ?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="saveattendence.php">
  <table width="400" border="1" align="center">
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Select School Name </td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><label>
        <select name="schid" id="schid" required="1" style="width:178px">
          <?php 
		$sql="select * from school";
		$res=mysql_query($sql);
		while($row=mysql_fetch_array($res))
		{
		?>
          <option value="<?php echo $row['schid'];?>"> <?php echo $row['schname']; ?> </option>
          <?php
		}
		?>
        </select>
      </label></td>
       <select name="schid" id="schid" required="1" style="width:178px>
	     <?php 
		$sql="select * from school";
		$res=mysql_query($sql);
		while($row=mysql_fetch_array($res))
		{
		?>
         <option value="<?php echo $row['schid'];?>"> <?php echo $row['schname']; ?> </option>
         <?php
		}
		?>
        </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Student Name </td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><label>
        <select name="studid" id="studid" required="1" style="width:178px">
          <?php 
		$sql="select * from student";
		$res=mysql_query($sql);
		while($row=mysql_fetch_array($res))
		{
		?>
          <option value="<?php echo $row['studid'];?>"> <?php echo $row['nos']; ?> </option>
          <?php
		}
		?>
        </select>
      </label></td>
      <label></td>
        <select name="studid" id="studid" required="1">
		  <?php 
		$sql="select * from student";
		$res=mysql_query($sql);
		while($row=mysql_fetch_array($res))
		{
		?>
          <option value="<?php echo $row['studid'];?>"> <?php echo $row['nos']; ?> </option>
          <?php
		}
		?>
        </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Date</td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><label>
        <select name="atdt" id="atdt" required="1" style="width:178px">
          <?php
		$i=1;
do{
		?>
          <option value="<?php echo $i?>"><?php echo $i;?></option>
          <?php
		$i++;
		}
		while($i<32)
		
		?>
        </select>
      </label></td>
      <label></td></label>
      <select name="atdt" id="atdt" required="1" style="width:178px">
        <?php
		$i=1;
do{
		?>
        <option value="<?php echo $i?>"><?php echo $i;?></option>
        <?php
		$i++;
		}
		while($i<32)
		
		?>
      </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Month</td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><label>
        <select name="atmnth" id="atmnth" required="1" style="width:178px">
          <option value="JANUARY">JANUARY</option>
          <option value="FEBRUARY">FEBRUARY</option>
          <option value="MARCH">MARCH</option>
          <option value="APRIL">APRIL</option>
          <option value="MAY">MAY</option>
          <option value="JUNE">JUNE</option>
          <option value="JULY">JULY</option>
          <option value="AUGUST">AUGUST</option>
          <option value="SEPTEMBER">SEPTEMBER</option>
          <option value="OCTOBER">OCTOBER</option>
          <option value="NOVEMBER">NOVEMBER</option>
          <option value="DECEMBER">DECEMBER</option>
        </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Year</td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><select name="atyr" id="atyr" required="1" style="width:178px">
          <?php
		$y=2010;
do{
		?>
          <option value="<?php echo $y;?>"><?php echo $y;?></option>
          <?php
		$y++;
		}
		while($y<2051)
		
		?>
      </select></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Level</td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><label>
        <select name="level" id="level" required="1" style="width:178px">
          <option value="PRIMARY">PRIMARY</option>
          <option value="HIGHER PRIMARY"> HIGHER PRIMARY</option>
          <option value="HIGH SCHOOL">HIGH SCHOOL</option>
        </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Standard</td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><label>
        <select name="std" id="std" required="1" style="width:178px">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
        </select>
      </label></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Attendence Status </td>
      <td width="50%" bgcolor="#FFFFCC" class="ldata"><input name="atstatus" type="text" id="atstatus" required="1" style="width:178px" /></td>
    </tr>
    <tr>
      <td align="center" bgcolor="#FFFFCC" class="ldata"><label>
        <input type="submit" name="Submit" value="Submit" />
      </label></td>
      <td align="center" bgcolor="#FFFFCC" class="ldata"><label>
        <input type="reset" name="Submit2" value="Reset" />
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php'); ?>
