
 <?php include('hdr1.php'); ?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
 <?php include('dbconnect.php');?>
<?php $sql="select * from attendence where schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' group by atdt";
$res=mysql_query($sql);


?>


<form name="form1" method="post" action="">
  <table width="200" border="1" align="center">
    <tr class="lhead" bgcolor="#663333" width="50%">
      <td align="center" rowspan="2">Sl. No. </td>
     <td  align="center" rowspan="2">Date</td>
      <td align="center" colspan="2">S.C.</td>
     
      <td align="center" colspan="2">S.T.</td>
      
      <td align="center" colspan="2">MINORITIES</td>
      
      <td align="center" colspan="2">OTHERS</td>
     
       <td align="center" colspan="2">TOTAL</td>
     
      <td  align="center" rowspan="2">GRAND TOTAL</td>
    </tr>
    <tr  class="lhead" bgcolor="#663333" width="50%">
     
      
      <td>Male</td>
      <td>Female</td>
      <td>Male</td>
      <td>Female</td>
      <td>Male</td>
      <td>Female</td>
      <td>Male</td>
      <td>Female</td>
      <td>Male</td>
      <td>Female</td>
     
    </tr>
	<?php 
	$i=1;	
	$m=0;
	While($row=mysql_fetch_array($res))
	{
	$style="dr";
	$style1="#FFFFCC";
	if($m % 2 != 0)
	{
	$style="sr";
	$style1="#FFFFCC";
	}
	$m++;
	$atdt=$row['atdt'];
	$sqlscm="select count(*) as cnt from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' and studid in(select studid from student where category='S.C.' and gender='Male') group by atdt and atmnth and atyr";
$resscm=mysql_query($sqlscm);
$rowscm=mysql_fetch_array($resscm);


$sqlscf="select count(*) as cnt from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' and studid in(select studid from student where category='S.C.' and gender='Female') group by atdt and atmnth and atyr";
$resscf=mysql_query($sqlscf);
$rowscf=mysql_fetch_array($resscf);


$sqlstm="select count(*) as cntstm from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' and studid in(select studid from student where category='S.T.' and gender='Male') group by atdt and atmnth and atyr";
$resstm=mysql_query($sqlstm);
$rowstm=mysql_fetch_array($resstm);
$stm=$rowstm['cntstm'];	

$sqlstf="select count(*) as cntstf from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' and studid in(select studid from student where category='S.T.' and gender='Female') group by atdt and atmnth and atyr";
$resstf=mysql_query($sqlstf);
$rowstf=mysql_fetch_array($resstf);
$stf=$rowstf['cntstf'];	

$sqlmim="select count(*) as cntmim from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' and studid in(select studid from student where category='Minorities' and gender='Male') group by atdt and atmnth and atyr";
$resmim=mysql_query($sqlmim);
$rowmim=mysql_fetch_array($resmim);

$sqlmif="select count(*) as cntmif from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' and studid in(select studid from student where category='Minorities' and gender='Female') group by atdt and atmnth and atyr";
$resmif=mysql_query($sqlmif);
$rowmif=mysql_fetch_array($resmif);

$sqlothm="select count(*) as cntothm from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' and studid in(select studid from student where category='Others' and gender='Male') group by atdt and atmnth and atyr";
$resothm=mysql_query($sqlothm);
$rowothm=mysql_fetch_array($resothm);

$sqlothf="select count(*) as cntothf from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' and studid in(select studid from student where category='Others' and gender='Female') group by atdt and atmnth and atyr";
$resothf=mysql_query($sqlothf);
$rowothf=mysql_fetch_array($resothf);

$sqltotm="select count(*) as cnttotm from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' and studid in(select studid from student where gender='Male') group by atdt and atmnth and atyr";
$restotm=mysql_query($sqltotm);
$rowtotm=mysql_fetch_array($restotm);

$sqltotf="select count(*) as cnttotf from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' and studid in(select studid from student where gender='Female') group by atdt and atmnth and atyr";
$restotf=mysql_query($sqltotf);
$rowtotf=mysql_fetch_array($restotf);


$sqlgt="select count(*) as cntgt from attendence where atdt='$atdt' and atstatus='P' and level='HIGHER SCHOOL' and schid='".$_POST['schid']."' and atmnth='".$_POST['atmnth']."' and atyr='".$_POST['atyr']."' group by atdt and atmnth and atyr";
$resgt=mysql_query($sqlgt);
$rowgt=mysql_fetch_array($resgt);

	?>	
    <tr bgcolor="<?php echo $style1?>"  onmouseover="MouseOver(this);" onmouseout="MouseOut(this);" class="lrow">
      <td class="<?php echo $style?>"><?php echo $i;?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $atdt."-".$_POST['atmnth']."-".$_POST['atyr'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $rowscm['cnt'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $rowscf['cnt'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $stm;?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $stf;?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $rowmim['cntmim'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $rowmif['cntmif'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $rowothm['cntothm'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $rowothf['cntothf'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $rowtotm['cnttotm'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $rowtotf['cnttotf'];?>&nbsp;</td>
      <td class="<?php echo $style?>"><?php echo $rowgt['cntgt'];?>&nbsp;</td>
    </tr>
	<?php
	$i++;
	}
	?>
	
  </table>
</form>
<?php include('ftr.php'); ?>