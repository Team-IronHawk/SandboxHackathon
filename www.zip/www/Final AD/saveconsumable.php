<?php include('dbconnect.php'); ?>
<?php
$cid=$_POST['cid'];
$cname=$_POST['cname'];
$l1rps=$_POST['l1rps'];
$l2rps=$_POST['l2rps'];
$l3rps=$_POST['l3rps'];
$sql="insert into comsumable values(null,'$cname','$l1rps','$l2rps','$l3rps')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New consumable details inseted successfully");
document.location="listconsumable.php";

</script>