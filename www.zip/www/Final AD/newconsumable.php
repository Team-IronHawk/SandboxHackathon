<?php include('hdr1.php');?>
<?php include('dbconnect.php'); ?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="saveconsumable.php">
  <p>&nbsp;</p>
  <table width="400" border="1" align="center">
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%" height="40px">Consumable Name</td>
      <td bgcolor="#FFFFCC" class="ldata">
	      <script>
        function cnam()
        {
          var x=document.getElementById("cname");
          if(!x.value.match(/^[a-zA-Z]+[ a-zA-Z]*$/))
          {
            window.alert("Please Enter Characters Only");
            document.getElementById("cname").value="";
            document.form.cname.focus();
           }
          else
          {
            x.value=x.value.toUpperCase();
            document.form.cname.focus();
          }
         }
      </script>
	  <input name="cname" type="text" id="cname"required x-moz-errormessage="Please enter Expendature name" onblur="cnam()"style="width:183px"></td>
    </tr>
    <tr>
      <td  class="lhead" bgcolor="#663333" width="50%">Requirement Per <br />Student For <br />Primary </td>
      <td bgcolor="#FFFFCC" class="ldata"><input name="l1rps" type="text" id="l1rps" required="1" style="width:183px"></td>
    </tr>
    <tr>
      <td class="lhead" bgcolor="#663333" width="50%">Requirement Per <br />Student For <br />Higher Primary </td>
      <td bgcolor="#FFFFCC" class="ldata"><input name="l2rps" type="text" id="l2rps" required="1" style="width:183px"></td>
    </tr>
    <tr>
      <td  class="lhead" bgcolor="#663333" width="50%">Requirement Per <br />Student For <br />High School </td>
      <td bgcolor="#FFFFCC" class="ldata"><input name="l3rps" type="text" id="l3rps" required="1"style="width:183px"></td>
    </tr>
    <tr align="center">
      <td bgcolor="#FFFFCC" class="ldata"><label>
        <input type="submit" name="Submit" value="Submit" class="button">
      </label></td>
      <td  bgcolor="#FFFFCC" class="ldata"><label>
        <input type="reset" name="Submit2" value="Reset" class="button">
      </label></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php');?>