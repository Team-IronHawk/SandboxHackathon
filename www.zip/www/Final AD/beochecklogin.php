<?php
$uname=$_POST['uname'];
$pwd=$_POST['pwd'];
if($uname=="beo" && $pwd=="beo")
{
header("location:beohome.php");
}
else{
?>
<script type="text/javascript" language="php">

alert("Inavlid Login Details....");
document.location="beologin.php";
</script>
<?php
}
?>
