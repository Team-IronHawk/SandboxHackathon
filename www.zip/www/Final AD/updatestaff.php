<?php include('dbconnect.php'); ?>
<?php
$staffid=$_POST['staffid'];
$schid=$_POST['schid'];
$name=$_POST['name'];
$stafftype=$_POST['stafftype'];
$designation=$_POST['designation'];
$doj=$_POST['doj'];
$experience=$_POST['experience'];
$phno=$_POST['phno'];
$addr=$_POST['addr'];
$sql="update staff set schid='$schid',name='$name',stafftype='$stafftype',designation='$designation',doj='$doj',experience='$experience',phno='$phno',addr='$addr' where staffid='$staffid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New Staff Details inseted successfully");
document.location="liststaff.php";
</script>