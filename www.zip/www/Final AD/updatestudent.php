<?php include('dbconnect.php'); ?>
<?php
$studid=$_POST['studid'];
$schid=$_POST['schid'];
$nos=$_POST['nos'];
$gender=$_POST['gender'];
$age=$_POST['age'];
$std=$_POST['std'];
$level=$_POST['level'];
$dob=$_POST['dob'];
$annualincome=$_POST['annualincome'];
$caste=$_POST['caste'];
$category=$_POST['category'];
$phydisable=$_POST['phydisable'];
$sql="update student set schid='$schid',nos='$nos',gender='$gender',age='$age',std='$std',level='$level',dob='$dob',annualincome='$annualincome',caste='$caste',category='$category',phydisable='$phydisable' where studid='$studid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New student details inseted successfully");
document.location="liststudent.php";
</script>