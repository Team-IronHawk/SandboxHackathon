<?php include('dbconnect.php'); ?>
<?php
$studid=$_POST['studid'];
$schid=$_POST['schid'];
$nos=$_POST['nos'];
$gender=$_POST['gender'];
$age=$_POST['age'];
$std=$_POST['std'];
$level=$_POST['level'];
$dob=$_POST['dob'];
$annualincome=$_POST['annualincome'];
$caste=$_POST['caste'];
$category=$_POST['category'];
$phydisable=$_POST['phydisable'];
$sql="insert into student values(null,'$schid','$nos','$gender','$age','$std','$level','$dob','$annualincome','$caste','$category','$phydisable')";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New student details inseted successfully");
document.location="liststudent.php";
</script>