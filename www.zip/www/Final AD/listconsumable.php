<?php include('hdr1.php');?>
<?php include('dbconnect.php'); ?>
<?php
$sql="select * from comsumable";
$res=mysql_query($sql);
?>
<link href="ourstyle.css" rel="stylesheet" type="text/css" />
<form name="form1" method="post" action="">
<table width="200" border="1" align="center">
  <tr bgcolor="#663333" class="lhead">
    <td>Enter consumable name </td>
    <td bgcolor="#663333">Requirement Per Student Of Primary </td>
    <td bgcolor="#663333">Requirement Per Student Of Higher Primary</td>
    <td bgcolor="#663333">Requirement Per Student Of High School </td>
    <td>Update</td>
    <td>Delete</td>
  </tr>
  <?php
	while($row=mysql_fetch_array($res))
	{
	?>
  <tr class="ldata">
    <td><?php  echo $row[cname]; ?>&nbsp;</td>
    <td><?php  echo $row[l1rps]; ?>&nbsp;</td>
    <td><?php  echo $row[l2rps]; ?>&nbsp;</td>
    <td><?php  echo $row[l3rps]; ?>&nbsp;</td>
    <td align="center"><a href="editconsumable.php?cid=<?php echo $row['cid'];?>"><img src="images/b_edit.png" /></a></td>
    <td align="center"><a href="deleteconsumable.php?cid=<?php echo $row['cid'];?>"><img src="images/b_drop.png" /></a></td>
  </tr>
  <?php
  }
  ?>
</table>
 <p align="center"><a href="newconsumable.php"></a> </p>
  <p>&nbsp;</p>
</form>
<?php include('ftr.php');?>
