
<?php include('dbconnect.php'); ?>
<?php
$regid=$_POST['regid'];
$schid=$_POST['schid'];
$scuname=$_POST['scuname'];
$scpwd=$_POST['scpwd'];
$sql="update registration set schid='$schid',scuname='$scuname',scpwd='$scpwd' where regid='$regid'";
mysql_query($sql);
?>
<script type="text/javascript" language="php">
alert("New Registration Details inserted successfully");
document.location="listregistration.php";
</script>